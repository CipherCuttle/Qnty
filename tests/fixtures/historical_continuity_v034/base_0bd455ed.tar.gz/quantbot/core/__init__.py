"""Core utilities for QuantBot."""
