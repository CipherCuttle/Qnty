"""SQLite paper accounting writer (Phase 2).

Implements the transactional writer for the paper ledger. Processes forward
observer signals and writes all ledger rows inside a single BEGIN IMMEDIATE
transaction, with full reconciliation before commit.

The writer is NOT the authority on a trusted run. It only commits raw accounting
artifacts to the DB and RETURNS a runner status code; it publishes no authoritative
``OK`` artifact. Authoritative paper trust is the read-only verifier's
``paper_verify_report.json`` (``sqlite_verify.verify_and_publish``) — a returned
``OK`` here means "this batch committed", not "this run is trusted".

Status codes (RUNNER STATUS ONLY — matching the JSONL runner contract):
  0 = OK
  2 = ABORTED
  3 = CONFIG_ERROR
  4 = CORRUPT_LEDGER
  5 = PRE_START
  6 = LEDGER_BUSY

See docs/ADR/0001-paper-sqlite-ledger.md and docs/paper_pnl_v1_schema.md.
"""

from __future__ import annotations

import csv
import json
import os
import sqlite3
import tempfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from quantbot.core.determinism import sha256_file
import quantbot.data.funding_loader as _funding_loader
from quantbot.data.multi_asset_loader import load_all_ohlcv
from quantbot.data.funding_loader import load_all_funding
from quantbot.data.types import Bar
from quantbot.paper import (
    BASELINE_LABEL,
    PAPER_ENGINE_VERSION,
    forward_obs_dir as default_forward_obs_dir,
    paper_output_dir,
)
from quantbot.paper.config import config_hash, load_config
from quantbot.paper.db import (
    LEDGER_BATCH_SNAPSHOT_REFERENCE_COLUMNS,
    PAPER_ENGINE_VERSION as DB_PAPER_ENGINE_VERSION,
    connect_writer,
    get_paper_db_path,
    validate_database_identity,
)
from quantbot.paper.engine import (
    build_funding_index,
    fill_id,
    funding_in_interval,
    new_state,
    run_engine,
)
from quantbot.paper.funding_coverage import check_funding_coverage_from_source_rows
from quantbot.paper.funding_source_snapshot import (
    build_funding_source_snapshot_envelope_v1,
    build_funding_source_snapshot_payload_v1,
    canonical_json,
    sha256_text,
    validate_funding_source_snapshot_envelope_v1,
)
from quantbot.paper.freshness import check_freshness, parse_bar_utc
from quantbot.paper.provenance import resolve_git_sha
from quantbot.paper.snapshots import (
    bar_commit_id,
    check_divergence,
    consumed_row_digest,
)

# ---------------------------------------------------------------------------
# Clock seam (patchable for deterministic tests)
# ---------------------------------------------------------------------------

def _now() -> datetime:
    """Return the current UTC time.

    A single indirection so tests can pin the writer's clock (freshness gate +
    run_ts) to a fixed instant, making the suite reproducible regardless of the
    wall clock. Production code calls this with no patching.
    """
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

EVENT_TYPE_ORDER: list[str] = [
    "signal_snapshot",
    "funding",
    "fill",
    "trade",
    "position_snapshot",
    "equity_snapshot",
]

EVENT_TYPE_RANK: dict[str, int] = {
    et: i for i, et in enumerate(EVENT_TYPE_ORDER)
}

# Status code constants
STATUS_OK = 0
STATUS_ABORTED = 2
STATUS_CONFIG_ERROR = 3
STATUS_CORRUPT_LEDGER = 4
STATUS_PRE_START = 5
STATUS_LEDGER_BUSY = 6


class FundingSourceSnapshotEmissionError(RuntimeError):
    """Raised when pending sidecar snapshot emission cannot complete safely."""


@dataclass(frozen=True)
class FundingSourceSnapshotReference:
    """DB reference values for one funding-source snapshot sidecar."""

    path: Path
    file_sha256: str
    source_bundle_sha256: str
    schema_version: str
    write_state: str
    created_at: str
    envelope: dict[str, Any]


# ---------------------------------------------------------------------------
# Helpers: event-chain construction
# ---------------------------------------------------------------------------

def _event_key(event_type: str, **attrs: Any) -> str:
    """Deterministic event key matching the JSONL id conventions."""
    if event_type == "signal_snapshot":
        return attrs["snapshot_id"]
    if event_type == "funding":
        return attrs["funding_id"]
    if event_type == "fill":
        return attrs["fill_id"]
    if event_type == "trade":
        return attrs["trade_id"]
    if event_type == "position_snapshot":
        return f"pos|{attrs['bar_ts']}"
    if event_type == "equity_snapshot":
        return f"eq|{attrs['bar_ts']}"
    raise ValueError(f"Unknown event_type: {event_type}")


def _event_bar_ts(event_type: str, attrs: dict[str, Any]) -> str | None:
    """Return the bar a row belongs to, for ledger_events.bar_ts + chain order.

    The engine names the anchoring bar differently per row type (fills key off
    the *signal* bar, trades off the *exit* bar); ``ledger_events.bar_ts`` and
    the deterministic chain order both need the resolved bar, not a bare
    ``attrs.get('bar_ts')`` which is ``None`` for fills/trades.
    """
    if event_type == "fill":
        return attrs.get("signal_bar_ts")
    if event_type == "trade":
        return attrs.get("exit_bar_ts")
    return attrs.get("bar_ts")


def _sort_events_for_chain(
    signal_snapshots: list[dict],
    funding_rows: list[dict],
    fill_rows: list[dict],
    trade_rows: list[dict],
    position_snapshots: list[dict],
    equity_snapshots: list[dict],
) -> list[tuple[str, dict[str, Any]]]:
    """Return [(event_type, attrs), ...] in deterministic chain order.

    Order: by resolved bar_ts, then by EVENT_TYPE_ORDER rank.
    Within each type, keys are sorted deterministically.
    """
    events: list[tuple[str, int, str, str, dict[str, Any]]] = []

    def _add(event_type: str, rows: list[dict]) -> None:
        rank = EVENT_TYPE_RANK[event_type]
        for row in rows:
            key = _event_key(event_type, **row)
            bar = _event_bar_ts(event_type, row) or ""
            events.append((event_type, rank, bar, key, row))

    _add("signal_snapshot", signal_snapshots)
    _add("funding", funding_rows)
    _add("fill", fill_rows)
    _add("trade", trade_rows)
    _add("position_snapshot", position_snapshots)
    _add("equity_snapshot", equity_snapshots)

    # bar_ts first, then event-type rank, then key — deterministic and stable.
    events.sort(key=lambda x: (x[2], x[1], x[3]))

    return [(et, attrs) for et, _, _, _, attrs in events]


# ---------------------------------------------------------------------------
# Helpers: DB write helpers (inside transaction).
# ---------------------------------------------------------------------------

def _insert_ledger_batch(
    conn: sqlite3.Connection,
    created_at: str,
    started_at: str | None,
    prior_watermark: str | None,
    paper_engine_version: str,
    config_hash_val: str,
    lane_id: str | None = None,
) -> int:
    """Insert a ledger_batches row; return the new batch_id.

    When *lane_id* is non-NULL (a new-lane DB whose ``paper_config.lane_id`` is set) the
    batch is stamped with it so every batch self-attests its lane
    (LEDGER_BATCH_LANE_STAMPING_PHASE3_PLAN). When it is None the INSERT is
    byte-identical to the baseline path and never references the ``lane_id`` column, so a
    v1/baseline DB — including a legacy DB whose ``ledger_batches`` lacks the column —
    keeps working unchanged.
    """
    if lane_id is None:
        cur = conn.execute(
            """
            INSERT INTO ledger_batches (
                created_at, started_at, prior_watermark_bar_ts,
                paper_engine_version, config_hash
            ) VALUES (?, ?, ?, ?, ?)
            """,
            (created_at, started_at, prior_watermark, paper_engine_version, config_hash_val),
        )
    else:
        cur = conn.execute(
            """
            INSERT INTO ledger_batches (
                created_at, started_at, prior_watermark_bar_ts,
                paper_engine_version, config_hash, lane_id
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                created_at,
                started_at,
                prior_watermark,
                paper_engine_version,
                config_hash_val,
                lane_id,
            ),
        )
    return cur.lastrowid  # type: ignore[no-any-return]


def _update_batch_on_commit(
    conn: sqlite3.Connection,
    batch_id: int,
    committed_at: str,
    new_watermark: str | None,
    first_event_seq: int | None,
    last_event_seq: int | None,
    event_count: int,
    committed_bar_count: int,
    git_sha: str | None,
) -> None:
    conn.execute(
        """
        UPDATE ledger_batches
        SET committed_at = ?,
            new_watermark_bar_ts = ?,
            first_event_seq = ?,
            last_event_seq = ?,
            event_count = ?,
            committed_bar_count = ?,
            git_sha = ?
        WHERE batch_id = ?
        """,
        (
            committed_at,
            new_watermark,
            first_event_seq,
            last_event_seq,
            event_count,
            committed_bar_count,
            git_sha,
            batch_id,
        ),
    )


def _require_ledger_batch_snapshot_reference_columns(
    conn: sqlite3.Connection,
) -> None:
    existing = {
        str(row["name"] if isinstance(row, sqlite3.Row) else row[1])
        for row in conn.execute("PRAGMA table_info(ledger_batches)").fetchall()
    }
    missing = [
        name
        for name in LEDGER_BATCH_SNAPSHOT_REFERENCE_COLUMNS
        if name not in existing
    ]
    if missing:
        raise FundingSourceSnapshotEmissionError(
            "ledger_batches missing funding source snapshot reference columns: "
            + ", ".join(missing)
        )


def _update_batch_snapshot_reference(
    conn: sqlite3.Connection,
    batch_id: int,
    snapshot_ref: FundingSourceSnapshotReference,
) -> None:
    conn.execute(
        """
        UPDATE ledger_batches
        SET funding_source_snapshot_path = ?,
            funding_source_snapshot_sha256 = ?,
            funding_source_snapshot_bundle_sha256 = ?,
            funding_source_snapshot_schema_version = ?,
            funding_source_snapshot_write_state = ?,
            funding_source_snapshot_created_at = ?
        WHERE batch_id = ?
        """,
        (
            str(snapshot_ref.path),
            snapshot_ref.file_sha256,
            snapshot_ref.source_bundle_sha256,
            snapshot_ref.schema_version,
            snapshot_ref.write_state,
            snapshot_ref.created_at,
            batch_id,
        ),
    )


def _insert_typed_rows_for_bar(
    conn: sqlite3.Connection,
    batch_id: int,
    bar_ts: str,
    bar_commit_id: str,
    engine_result: Any,
    event_seq_by_key: dict[str, int],
    signal_snapshots_for_bar: list[dict],
    funding_for_bar: list[dict],
    fills_for_bar: list[dict],
    trades_for_bar: list[dict],
    position_snapshot_for_bar: dict | None,
    equity_snapshot_for_bar: dict | None,
    open_positions_after: dict[str, dict],
) -> None:
    """Insert all typed rows for one committed bar.

    `event_seq_by_key` maps (event_type, event_key) -> ledger_events.seq
    (already inserted). The key is the (type, key) PAIR, not the key alone:
    an exit fill and its closing trade share the same id, so keying by the
    bare event_key would collide and misroute the typed rows.
    """
    # signal_snapshots
    for snap in signal_snapshots_for_bar:
        seq = event_seq_by_key[("signal_snapshot", _event_key("signal_snapshot", **snap))]
        conn.execute(
            """
            INSERT INTO signal_snapshots (
                seq, batch_id, snapshot_id, bar_ts, bar_commit_id,
                bar_index, active_symbols, portfolio_heat,
                heat_cap_triggered, weighted_return,
                source_observation_digest, source_observation_mtime, run_ts
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                seq,
                batch_id,
                snap["snapshot_id"],
                snap["bar_ts"],
                snap["bar_commit_id"],
                snap.get("bar_index"),
                json.dumps(sorted(snap.get("active_symbols", []))),
                snap.get("portfolio_heat"),
                1 if snap.get("heat_cap_triggered") else 0,
                snap.get("weighted_return"),
                snap.get("source_observation_digest", ""),
                snap.get("source_observation_mtime"),
                snap.get("run_ts", ""),
            ),
        )

    # funding
    for f in funding_for_bar:
        seq = event_seq_by_key[("funding", _event_key("funding", **f))]
        conn.execute(
            """
            INSERT INTO funding (
                seq, batch_id, funding_id, bar_commit_id, symbol,
                bar_ts, window_start, window_end, notional_usd,
                funding_rate, funding_events, rate_available, funding_amount
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                seq,
                batch_id,
                f["funding_id"],
                f["bar_commit_id"],
                f["symbol"],
                f["bar_ts"],
                f["window_start"],
                f["window_end"],
                f["notional_usd"],
                f["funding_rate"],
                f["funding_events"],
                1 if f["rate_available"] else 0,
                f["funding_amount"],
            ),
        )

    # fills
    for fl in fills_for_bar:
        seq = event_seq_by_key[("fill", _event_key("fill", **fl))]
        conn.execute(
            """
            INSERT INTO fills (
                seq, batch_id, fill_id, bar_commit_id, signal_bar_ts,
                fill_ts, symbol, side, kind, qty, open_price,
                fill_price, slippage_bps, fee, backfill
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                seq,
                batch_id,
                fl["fill_id"],
                fl["bar_commit_id"],
                fl["signal_bar_ts"],
                fl["fill_ts"],
                fl["symbol"],
                fl["side"],
                fl["kind"],
                fl["qty"],
                fl["open_price"],
                fl["fill_price"],
                fl["slippage_bps"],
                fl["fee"],
                1 if fl.get("backfill") else 0,
            ),
        )

    # trades
    for tr in trades_for_bar:
        seq = event_seq_by_key[("trade", _event_key("trade", **tr))]
        conn.execute(
            """
            INSERT INTO trades (
                seq, batch_id, trade_id, bar_commit_id, symbol,
                entry_fill_id, exit_fill_id, entry_bar_ts, exit_bar_ts,
                qty, entry_price, exit_price, gross_pnl, fees,
                funding, net_pnl, hold_bars, backfill
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                seq,
                batch_id,
                tr["trade_id"],
                tr["bar_commit_id"],
                tr["symbol"],
                tr["entry_fill_id"],
                tr["exit_fill_id"],
                tr["entry_bar_ts"],
                tr["exit_bar_ts"],
                tr["qty"],
                tr["entry_price"],
                tr["exit_price"],
                tr["gross_pnl"],
                tr["fees"],
                tr["funding"],
                tr["net_pnl"],
                tr["hold_bars"],
                1 if tr.get("backfill") else 0,
            ),
        )

    # position_snapshot (+ symbols child table)
    if position_snapshot_for_bar:
        seq = event_seq_by_key[
            ("position_snapshot", _event_key("position_snapshot", **position_snapshot_for_bar))
        ]
        ps = position_snapshot_for_bar
        conn.execute(
            """
            INSERT INTO position_snapshots (
                seq, batch_id, bar_ts, bar_commit_id,
                open_symbols, num_open
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                seq,
                batch_id,
                ps["bar_ts"],
                ps["bar_commit_id"],
                json.dumps(sorted(ps.get("open_symbols", []))),
                ps.get("num_open", 0),
            ),
        )
        # child rows
        for sym, pos in sorted(open_positions_after.items()):
            unrealized_gross = pos.get("unrealized_gross", 0.0)
            conn.execute(
                """
                INSERT INTO position_snapshot_symbols (
                    snapshot_seq, symbol, qty, entry_price,
                    entry_fill_id, entry_bar_ts, unrealized_gross
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    seq,
                    sym,
                    pos["qty"],
                    pos["entry_price"],
                    pos["entry_fill_id"],
                    pos["entry_bar_ts"],
                    unrealized_gross,
                ),
            )

    # equity_snapshot
    if equity_snapshot_for_bar:
        seq = event_seq_by_key[
            ("equity_snapshot", _event_key("equity_snapshot", **equity_snapshot_for_bar))
        ]
        eq = equity_snapshot_for_bar
        conn.execute(
            """
            INSERT INTO equity_snapshots (
                seq, batch_id, bar_ts, bar_commit_id,
                realized_gross_pnl, unrealized_pnl, funding_cum,
                fees_cum, equity, drawdown, num_open
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                seq,
                batch_id,
                eq["bar_ts"],
                eq["bar_commit_id"],
                eq["realized_gross_pnl"],
                eq["unrealized_pnl"],
                eq["funding_cum"],
                eq["fees_cum"],
                eq["equity"],
                eq["drawdown"],
                eq["num_open"],
            ),
        )


# ---------------------------------------------------------------------------
# Helpers: build snapshots for SQLite (matching JSONL runner semantics).
# ---------------------------------------------------------------------------

def _build_signal_snapshots_for_bars(
    per_bar_obs: list[dict],
    processed_bar_ts: set[str],
    engine_version: str,
    config_hash_val: str,
) -> list[dict]:
    """Build signal_snapshot rows for bars that got new accounting.

    Mirrors snapshots.build_snapshots() but returns dicts suitable
    for SQLite insertion.
    """
    results: list[dict] = []
    for obs in per_bar_obs:
        ts = obs["timestamp"]
        if ts not in processed_bar_ts:
            continue
        commit_id = bar_commit_id(obs, ts, engine_version, config_hash_val)
        snap_id = commit_id  # snapshot_id = bar_commit_id for v1
        results.append(
            {
                "snapshot_id": snap_id,
                "bar_ts": ts,
                "bar_commit_id": commit_id,
                "bar_index": obs.get("bar_index"),
                "active_symbols": sorted(obs.get("active_symbols", [])),
                "portfolio_heat": obs.get("portfolio_heat", 0.0),
                "heat_cap_triggered": bool(obs.get("heat_cap_triggered", False)),
                "weighted_return": obs.get("weighted_return", 0.0),
                "source_observation_digest": consumed_row_digest(obs),
                "source_observation_mtime": None,
                "run_ts": _now().strftime("%Y-%m-%dT%H:%M:%SZ"),
            }
        )
    return results


def _snapshot_positions_with_unrealized(
    open_positions: dict[str, dict],
    close_by_symbol_ts: dict[str, dict[str, float]],
    bar_ts: str,
) -> dict[str, dict]:
    positions: dict[str, dict] = {}
    for sym, pos in open_positions.items():
        marked = dict(pos)
        close = close_by_symbol_ts.get(sym, {}).get(bar_ts)
        unrealized_gross = 0.0
        if close is not None:
            qty = float(marked["qty"])
            entry = float(marked["entry_price"])
            side = str(marked.get("side", "long")).lower()
            if side == "short":
                unrealized_gross = (entry - close) * abs(qty)
            else:
                unrealized_gross = (close - entry) * qty
        marked["unrealized_gross"] = round(unrealized_gross, 8)
        positions[sym] = marked
    return positions


def _group_engine_result_by_bar(
    engine_result: Any,
    per_bar_obs: list[dict],
    engine_version: str,
    config_hash_val: str,
    prior_open_positions: dict[str, dict] | None = None,
) -> list[dict]:
    """Group engine result rows into per-bar dicts for SQLite insertion.

    Returns a list of dicts, one per bar that was committed, each carrying:
      bar_ts, bar_commit_id,
      signal_snapshots, funding, fills, trades,
      position_snapshot, equity_snapshot,
      open_positions_after

    ``prior_open_positions`` seeds the per-bar open-book walk with the positions
    already open at the START of this run (loaded from the DB on a restart), so
    the per-bar position_snapshots reflect carried-over positions — not an empty
    book. Without it, a restart batch's position_snapshots would disagree with
    the (correctly seeded) position_snapshot_symbols child rows.
    """
    # Build bar_commit_id lookup
    commit_id_by_ts: dict[str, str] = {}
    for obs in per_bar_obs:
        ts = obs["timestamp"]
        commit_id_by_ts[ts] = bar_commit_id(obs, ts, engine_version, config_hash_val)

    # Index engine result rows by bar_ts
    equity_by_ts: dict[str, dict] = {}
    for eq in engine_result.equity:
        equity_by_ts[eq["bar_ts"]] = eq

    funding_by_ts: dict[str, list[dict]] = {}
    for f in engine_result.funding:
        funding_by_ts.setdefault(f["bar_ts"], []).append(f)

    fills_by_ts: dict[str, list[dict]] = {}
    for fl in engine_result.fills:
        ts = fl["signal_bar_ts"]
        fills_by_ts.setdefault(ts, []).append(fl)

    trades_by_ts: dict[str, list[dict]] = {}
    for tr in engine_result.trades:
        ts = tr["exit_bar_ts"]
        trades_by_ts.setdefault(ts, []).append(tr)

    # Walk in sorted order, tracking open_positions incrementally. Seed with the
    # positions already open at the start of this run (restart state) so the
    # per-bar pre-fill snapshots include carried-over positions.
    sorted_ts = sorted(equity_by_ts.keys())
    open_positions: dict[str, dict] = {
        sym: dict(pos) for sym, pos in (prior_open_positions or {}).items()
    }
    bars: list[dict] = []

    for ts in sorted_ts:
        eq = equity_by_ts[ts]
        commit_id = commit_id_by_ts.get(ts, "")

        # Build position_snapshot (pre-fill book = current open_positions)
        pos_snap = {
            "bar_ts": ts,
            "bar_commit_id": commit_id,
            "open_symbols": sorted(open_positions.keys()),
            "num_open": len(open_positions),
        }

        bar_dict: dict[str, Any] = {
            "bar_ts": ts,
            "bar_commit_id": commit_id,
            "signal_snapshots": _build_signal_snapshots_for_bars(
                [obs for obs in per_bar_obs if obs["timestamp"] == ts],
                {ts},
                engine_version,
                config_hash_val,
            ),
            "funding": funding_by_ts.get(ts, []),
            "fills": fills_by_ts.get(ts, []),
            "trades": trades_by_ts.get(ts, []),
            "position_snapshot": pos_snap,
            "equity_snapshot": eq,
            "open_positions_after": dict(open_positions),
        }
        bars.append(bar_dict)

        # Apply fills for this bar to open_positions (post-snapshot)
        for fl in fills_by_ts.get(ts, []):
            sym = fl["symbol"]
            if fl["kind"] == "entry":
                open_positions[sym] = {
                    "entry_fill_id": fl["fill_id"],
                    "entry_price": fl["fill_price"],
                    "qty": fl["qty"],
                    "entry_bar_ts": ts,
                    "entry_fill_ts": fl["fill_ts"],
                    "funding_accrued": 0.0,
                    "entry_fee": fl["fee"],
                    "hold_bars": 0,
                    "unrealized_gross": 0.0,
                }
            elif fl["kind"] == "exit":
                open_positions.pop(sym, None)

    return bars


# ---------------------------------------------------------------------------
# Reconciliation inside transaction (before commit).
# ---------------------------------------------------------------------------

def _reconcile_batch_inside_tx(
    conn: sqlite3.Connection,
    batch_id: int,
    event_count_expected: int,
    events_inserted: list[tuple[str, str, str, str | None]],
    typed_row_counts: dict[str, int],
    open_positions_reconstructed: dict[str, dict],
    state_accumulators: dict[str, float],
    prior_peak_equity: float,
    initial_equity: float,
    fee_bps: float,
) -> list[str]:
    """Run reconciliation checks BEFORE commit. Return list of failure strings."""
    failures: list[str] = []

    # 1. Batch event count matches inserted rows
    row = conn.execute(
        "SELECT COUNT(*) AS cnt FROM ledger_events WHERE batch_id = ?",
        (batch_id,),
    ).fetchone()
    if row and row["cnt"] != event_count_expected:
        failures.append(
            f"Batch event count mismatch: expected {event_count_expected}, "
            f"got {row['cnt']}"
        )

    # 2. Event type / typed row counts match
    for et in EVENT_TYPE_ORDER:
        expected = typed_row_counts.get(et, 0)
        actual = conn.execute(
            "SELECT COUNT(*) AS cnt FROM ledger_events WHERE batch_id = ? AND event_type = ?",
            (batch_id, et),
        ).fetchone()["cnt"]
        if expected != actual:
            failures.append(
                f"Event type {et} count mismatch: expected {expected}, got {actual}"
            )

    # 3. prev_seq chain coherence (across batches). The batch's first event must
    # link to the immediately preceding GLOBAL event (NULL only if it is the very
    # first event ever); subsequent events link to their predecessor in-batch.
    events = conn.execute(
        "SELECT seq, prev_seq FROM ledger_events WHERE batch_id = ? ORDER BY seq",
        (batch_id,),
    ).fetchall()
    if events:
        first = events[0]
        global_pred = conn.execute(
            "SELECT MAX(seq) FROM ledger_events WHERE seq < ?", (first["seq"],)
        ).fetchone()[0]
        if first["prev_seq"] != global_pred:
            failures.append(
                f"First batch event seq={first['seq']} prev_seq={first['prev_seq']} "
                f"!= global predecessor {global_pred}"
            )
        prev = first["seq"]
        for erow in events[1:]:
            if erow["prev_seq"] != prev:
                failures.append(
                    f"Event seq={erow['seq']} prev_seq={erow['prev_seq']} "
                    f"!= expected {prev}"
                )
            prev = erow["seq"]

    # 4. Every typed row references valid event
    for et in EVENT_TYPE_ORDER:
        table = {
            "signal_snapshot": "signal_snapshots",
            "funding": "funding",
            "fill": "fills",
            "trade": "trades",
            "position_snapshot": "position_snapshots",
            "equity_snapshot": "equity_snapshots",
        }[et]
        orphans = conn.execute(
            f"""
            SELECT COUNT(*) AS cnt FROM {table}
            WHERE batch_id = ? AND seq NOT IN (
                SELECT seq FROM ledger_events WHERE batch_id = ? AND event_type = ?
            )
            """,
            (batch_id, batch_id, et),
        ).fetchone()
        if orphans and orphans["cnt"] > 0:
            failures.append(f"Orphan typed rows in {table} for batch {batch_id}")

    # 5. Every event has exactly one typed row
    for et in EVENT_TYPE_ORDER:
        table = {
            "signal_snapshot": "signal_snapshots",
            "funding": "funding",
            "fill": "fills",
            "trade": "trades",
            "position_snapshot": "position_snapshots",
            "equity_snapshot": "equity_snapshots",
        }[et]
        event_count = conn.execute(
            "SELECT COUNT(*) AS cnt FROM ledger_events WHERE batch_id = ? AND event_type = ?",
            (batch_id, et),
        ).fetchone()["cnt"]
        typed_count = conn.execute(
            f"SELECT COUNT(*) AS cnt FROM {table} WHERE batch_id = ?",
            (batch_id,),
        ).fetchone()["cnt"]
        if event_count != typed_count:
            failures.append(
                f"Event/typed row count mismatch for {et}: "
                f"events={event_count}, typed={typed_count}"
            )

    # 6. No fill before forward_start_ts. Compare PARSED instants in Python, not a SQL
    # string compare: a boundary fill's signal_bar_ts ('...T00:00:00') is stored naive
    # while forward_start_ts carries a trailing Z ('...T00:00:00Z'), and a lexicographic
    # `signal_bar_ts < forward_start_ts` would wrongly flag a fill AT the boundary as
    # "before" it (false CORRUPT_LEDGER). An unparseable signal_bar_ts fails closed.
    cfg = conn.execute("SELECT forward_start_ts FROM paper_config WHERE id = 1").fetchone()
    if cfg:
        fwd = cfg["forward_start_ts"]
        fwd_dt = parse_bar_utc(fwd)
        fill_rows = conn.execute(
            """
            SELECT f.signal_bar_ts AS signal_bar_ts FROM fills f
            JOIN ledger_events e ON e.seq = f.seq
            WHERE e.batch_id = ?
            """,
            (batch_id,),
        ).fetchall()
        pre_count = 0
        for fr in fill_rows:
            try:
                before = parse_bar_utc(fr["signal_bar_ts"]) < fwd_dt
            except (TypeError, ValueError):
                before = True  # unparseable signal_bar_ts -> fail closed
            if before:
                pre_count += 1
        if pre_count > 0:
            failures.append(f"Found {pre_count} fills before forward_start_ts {fwd}")

    # 7. Fill fee arithmetic: fee = fill_price * qty * fee_bps / 10000
    fee_rate = fee_bps / 10_000.0
    bad_fees = conn.execute(
        """
        SELECT f.seq, f.fill_price, f.qty, f.fee
        FROM fills f
        JOIN ledger_events e ON e.seq = f.seq
        WHERE e.batch_id = ?
          AND ABS(f.fee - (f.fill_price * f.qty * ?)) > 1e-8
        """,
        (batch_id, fee_rate),
    ).fetchall()
    for row in bad_fees:
        expected_fee = row["fill_price"] * row["qty"] * fee_rate
        failures.append(
            f"Fill fee mismatch seq={row['seq']}: "
            f"expected {expected_fee:.8f}, got {row['fee']:.8f}"
        )

    # 8. Trade gross/net arithmetic
    bad_trades = conn.execute(
        """
        SELECT t.seq, t.gross_pnl, t.fees, t.funding, t.net_pnl
        FROM trades t
        JOIN ledger_events e ON e.seq = t.seq
        WHERE e.batch_id = ?
          AND ABS(t.net_pnl - (t.gross_pnl - t.fees - t.funding)) > 1e-8
        """,
        (batch_id,),
    ).fetchall()
    for row in bad_trades:
        failures.append(
            f"Trade net_pnl mismatch seq={row['seq']}: "
            f"gross={row['gross_pnl']}, fees={row['fees']}, "
            f"funding={row['funding']}, net={row['net_pnl']}"
        )

    # 9. Funding amount arithmetic: amount = notional_usd * funding_rate
    bad_funding = conn.execute(
        """
        SELECT f.seq, f.notional_usd, f.funding_rate, f.funding_amount, f.rate_available
        FROM funding f
        JOIN ledger_events e ON e.seq = f.seq
        WHERE e.batch_id = ? AND f.rate_available = 1
          AND ABS(f.funding_amount - (f.notional_usd * f.funding_rate)) > 1e-8
        """,
        (batch_id,),
    ).fetchall()
    for row in bad_funding:
        expected_amount = row["notional_usd"] * row["funding_rate"]
        failures.append(
            f"Funding amount mismatch seq={row['seq']}: "
            f"expected {expected_amount:.8f}, got {row['funding_amount']:.8f}"
        )

    # 10. Equity balance arithmetic
    eq_rows = conn.execute(
        """
        SELECT eq.equity, eq.realized_gross_pnl, eq.unrealized_pnl,
               eq.funding_cum, eq.fees_cum
        FROM equity_snapshots eq
        JOIN ledger_events e ON e.seq = eq.seq
        WHERE e.batch_id = ?
        ORDER BY eq.seq
        """,
        (batch_id,),
    ).fetchall()
    for erow in eq_rows:
        expected_equity = (
            initial_equity
            + erow["realized_gross_pnl"]
            - erow["fees_cum"]
            - erow["funding_cum"]
            + erow["unrealized_pnl"]
        )
        if abs(erow["equity"] - expected_equity) > 1e-6:
            failures.append(
                f"Equity balance mismatch: expected {expected_equity:.8f}, "
                f"got {erow['equity']:.8f}"
            )

    # 11. Drawdown arithmetic.
    # The running peak is a CROSS-batch quantity: the engine seeds it from the prior committed
    # ledger_state.peak_equity and carries it forward (engine.run_engine), so a continuation
    # batch whose equity sits below an earlier batch's peak records a positive drawdown. Seeding
    # the replay at initial_equity and walking ONLY this batch's equity rows would recompute
    # drawdown == 0 and a too-low peak — a FALSE CORRUPT_LEDGER on every dip after a prior high
    # (the VM batch-4 failure). Seed from the prior committed peak instead; for the first batch
    # prior_peak_equity == initial_equity, so first-batch behavior is unchanged. (No tolerance is
    # loosened — the comparison against the stored drawdown stays at 1e-8.)
    peak = max(initial_equity, prior_peak_equity)
    eq_all = conn.execute(
        """
        SELECT eq.equity, eq.drawdown
        FROM equity_snapshots eq
        JOIN ledger_events e ON e.seq = eq.seq
        WHERE e.batch_id = ?
        ORDER BY eq.seq
        """,
        (batch_id,),
    ).fetchall()
    for erow in eq_all:
        if erow["equity"] > peak:
            peak = erow["equity"]
        expected_dd = (peak - erow["equity"]) / peak if peak > 0 else 0.0
        if abs(erow["drawdown"] - expected_dd) > 1e-8:
            failures.append(
                f"Drawdown mismatch: expected {expected_dd:.8f}, "
                f"got {erow['drawdown']:.8f}"
            )

    # 12. ledger_state accumulators match
    state = conn.execute("SELECT * FROM ledger_state WHERE id = 1").fetchone()
    if state:
        if abs(state["realized_gross"] - state_accumulators.get("realized_gross", 0.0)) > 1e-8:
            failures.append("ledger_state.realized_gross mismatch after batch")
        if abs(state["fees_cum"] - state_accumulators.get("fees_cum", 0.0)) > 1e-8:
            failures.append("ledger_state.fees_cum mismatch after batch")
        if abs(state["funding_cum"] - state_accumulators.get("funding_cum", 0.0)) > 1e-8:
            failures.append("ledger_state.funding_cum mismatch after batch")
        if peak > 0 and abs(state["peak_equity"] - peak) > 1e-8:
            failures.append("ledger_state.peak_equity mismatch after batch")

    # 13. open_positions matches reconstructed
    db_positions = {
        row["symbol"]: dict(row)
        for row in conn.execute("SELECT * FROM open_positions").fetchall()
    }
    for sym, pos in open_positions_reconstructed.items():
        if sym not in db_positions:
            failures.append(f"open_positions: symbol {sym} missing after batch")
        else:
            db_pos = db_positions[sym]
            if abs(db_pos["qty"] - pos["qty"]) > 1e-8:
                failures.append(f"open_positions: qty mismatch for {sym}")
            if abs(db_pos["entry_price"] - pos["entry_price"]) > 1e-8:
                failures.append(f"open_positions: entry_price mismatch for {sym}")

    # 14. watermark equals latest committed equity bar
    latest_eq = conn.execute(
        """
        SELECT eq.bar_ts FROM equity_snapshots eq
        JOIN ledger_events e ON e.seq = eq.seq
        WHERE e.batch_id = ?
        ORDER BY eq.seq DESC LIMIT 1
        """,
        (batch_id,),
    ).fetchone()
    state = conn.execute("SELECT watermark_bar_ts FROM ledger_state WHERE id = 1").fetchone()
    if latest_eq and state:
        if state["watermark_bar_ts"] != latest_eq["bar_ts"]:
            failures.append(
                f"Watermark mismatch: state={state['watermark_bar_ts']}, "
                f"latest_equity={latest_eq['bar_ts']}"
            )

    return failures


# ---------------------------------------------------------------------------
# Funding source snapshot sidecar emission (outside DB schema v1).
# ---------------------------------------------------------------------------

def _source_row_get(row: Any, key: str, default: Any = None) -> Any:
    if isinstance(row, dict):
        return row.get(key, default)
    get = getattr(row, "get", None)
    if callable(get):
        return get(key, default)
    return getattr(row, key, default)


def _funding_df_has_column(funding_df: Any, column: str) -> bool:
    columns = getattr(funding_df, "columns", ())
    return column in columns


def _iter_funding_df_rows(funding_df: Any) -> list[Any]:
    if funding_df is None or getattr(funding_df, "empty", False):
        return []
    if hasattr(funding_df, "iterrows"):
        return [row for _, row in funding_df.iterrows()]
    return list(funding_df)


def _funding_source_symbol_from_path(path: Path) -> str:
    name = path.name
    if name.endswith("_8h_funding.csv"):
        return name.removesuffix("_8h_funding.csv")
    if "_" in name:
        return name.split("_", 1)[0]
    return path.stem


def _required_funding_windows_for_snapshot(
    required_funding_rows: list[dict],
) -> list[dict[str, str]]:
    windows: dict[tuple[str, str, str], dict[str, str]] = {}
    for row in required_funding_rows:
        symbol = str(row.get("symbol", ""))
        window_start = str(row.get("window_start", ""))
        window_end = str(row.get("window_end", ""))
        if not symbol or not window_start or not window_end:
            raise FundingSourceSnapshotEmissionError(
                "source snapshot cannot derive required funding window identity "
                f"from row {row!r}"
            )
        key = (symbol, window_start, window_end)
        windows[key] = {
            "symbol": symbol,
            "window_start": window_start,
            "window_end": window_end,
            "required_by": "paper_engine_funding_interval",
        }
    return [windows[key] for key in sorted(windows)]


def _funding_source_csv_paths_for_snapshot(
    required_windows: list[dict[str, str]],
    funding_df: Any,
    data_dir: Path | None,
) -> list[Path]:
    symbols = sorted({window["symbol"] for window in required_windows})
    if not symbols:
        return []

    # Test and future non-loader seams may attach explicit source paths to the
    # in-memory funding rows. When present, those paths are stronger than the
    # loader's module-level data dir and keep manual tmp DB tests hermetic.
    explicit_paths: set[Path] = set()
    if _funding_df_has_column(funding_df, "source_file_path"):
        required_symbols = set(symbols)
        for row in _iter_funding_df_rows(funding_df):
            symbol = str(_source_row_get(row, "symbol", ""))
            if symbol in required_symbols:
                raw_path = _source_row_get(row, "source_file_path")
                if raw_path:
                    explicit_paths.add(Path(str(raw_path)))
    if explicit_paths:
        return sorted(explicit_paths, key=lambda path: str(path))

    funding_data_dir = Path(data_dir) if data_dir is not None else Path(_funding_loader._DATA_DIR)
    return [funding_data_dir / f"{symbol}_8h_funding.csv" for symbol in symbols]


def _read_funding_source_csv_rows(source_file_paths: list[Path]) -> list[dict[str, Any]]:
    source_rows: list[dict[str, Any]] = []
    for path in source_file_paths:
        symbol = _funding_source_symbol_from_path(path)
        try:
            with path.open("r", newline="", encoding="utf-8") as fh:
                reader = csv.DictReader(fh)
                if reader.fieldnames is None:
                    raise FundingSourceSnapshotEmissionError(
                        f"funding source CSV has no header: {path}"
                    )
                missing = {"fundingTime", "fundingRate"} - set(reader.fieldnames)
                if missing:
                    raise FundingSourceSnapshotEmissionError(
                        f"funding source CSV {path} missing column(s): {sorted(missing)}"
                    )
                for row_index, row in enumerate(reader, start=1):
                    try:
                        funding_time_ms = int(row["fundingTime"])
                    except (TypeError, ValueError) as exc:
                        raise FundingSourceSnapshotEmissionError(
                            f"funding source CSV {path} row {row_index} has invalid "
                            f"fundingTime {row.get('fundingTime')!r}"
                        ) from exc
                    source_rows.append(
                        {
                            "symbol": symbol,
                            "fundingTime_ms": funding_time_ms,
                            "source_file_path": str(path),
                            "row_index": row_index,
                            "funding_rate": str(row["fundingRate"]),
                        }
                    )
        except FundingSourceSnapshotEmissionError:
            raise
        except OSError as exc:
            raise FundingSourceSnapshotEmissionError(
                f"funding source CSV cannot be read for snapshot digest: {path}: {exc}"
            ) from exc
    return source_rows


def _sqlite_value(row: sqlite3.Row, key: str) -> Any:
    return row[key] if key in row.keys() else None


def _db_identity_hash_before_snapshot(
    conn: sqlite3.Connection,
    db_path: Path,
    db_config: dict[str, Any],
    state_row: sqlite3.Row,
) -> str:
    latest_batch_id = conn.execute("SELECT MAX(batch_id) FROM ledger_batches").fetchone()[0]
    latest_event_seq = conn.execute("SELECT MAX(seq) FROM ledger_events").fetchone()[0]
    identity = {
        "db_path_reference": str(db_path),
        "paper_engine_version": db_config.get("paper_engine_version"),
        "config_hash": db_config.get("config_hash"),
        "lane_id": db_config.get("lane_id"),
        "watermark_bar_ts": _sqlite_value(state_row, "watermark_bar_ts"),
        "latest_batch_id": latest_batch_id,
        "latest_event_seq": latest_event_seq,
    }
    return sha256_text(canonical_json(identity))


def _fsync_directory(path: Path) -> None:
    try:
        dir_fd = os.open(path, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


def _write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=path.parent,
        text=True,
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(value, fh, ensure_ascii=True, indent=2, sort_keys=True)
            fh.write("\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, path)
        _fsync_directory(path.parent)
    except Exception:
        try:
            tmp_path.unlink()
        except OSError:
            pass
        raise


def _emit_pending_funding_source_snapshot(
    *,
    conn: sqlite3.Connection,
    db_path: Path,
    db_config: dict[str, Any],
    state_row: sqlite3.Row,
    required_funding_rows: list[dict],
    funding_df: Any,
    data_dir: Path | None,
    created_at: str,
    batch_git_sha: str,
    batch_end_watermark: str | None,
) -> FundingSourceSnapshotReference:
    try:
        _require_ledger_batch_snapshot_reference_columns(conn)
        required_windows = _required_funding_windows_for_snapshot(required_funding_rows)
        source_file_paths = _funding_source_csv_paths_for_snapshot(
            required_windows,
            funding_df,
            data_dir,
        )
        if required_windows and not source_file_paths:
            raise FundingSourceSnapshotEmissionError(
                "source snapshot has required funding windows but no source CSV paths"
            )
        source_rows = _read_funding_source_csv_rows(source_file_paths)
        db_identity_hash_before = _db_identity_hash_before_snapshot(
            conn,
            db_path,
            db_config,
            state_row,
        )
        batch_start_watermark = _sqlite_value(state_row, "watermark_bar_ts")
        pending_seed = {
            "db_path_reference": str(db_path),
            "created_at": created_at,
            "batch_start_watermark": batch_start_watermark,
            "batch_end_watermark": batch_end_watermark,
            "required_windows": required_windows,
        }
        pending_batch_id = f"pending-{sha256_text(canonical_json(pending_seed))[:24]}"
        lane_id = str(db_config.get("lane_id") or "paper_pnl_v1")

        payload = build_funding_source_snapshot_payload_v1(
            source_rows=source_rows,
            source_file_paths=source_file_paths,
            required_windows=required_windows,
            generated_at_utc=created_at,
            lane_id=lane_id,
            output_dir=str(db_path.parent),
            writer_or_verifier_command=(
                "quantbot.paper.sqlite_writer.run_sqlite_accounting "
                f"--db-path {db_path}"
            ),
            qnty_git_commit=batch_git_sha,
            write_state="pending",
            db_identity_hash_before=db_identity_hash_before,
            pending_batch_id=pending_batch_id,
            ledger_batch_id=None,
            batch_identity_matches=False,
            evaluation_identity_matches=True,
            db_path_reference=str(db_path),
            batch_start_watermark=batch_start_watermark,
            batch_end_watermark=batch_end_watermark,
        )
        if required_windows and not payload.get("source_files"):
            raise FundingSourceSnapshotEmissionError(
                "source snapshot digest construction produced no source_files"
            )
        envelope = build_funding_source_snapshot_envelope_v1(payload)
        validation_reasons = validate_funding_source_snapshot_envelope_v1(envelope)
        if validation_reasons:
            raise FundingSourceSnapshotEmissionError(
                "source snapshot envelope validation failed: "
                + ", ".join(validation_reasons)
            )

        source_bundle_sha256 = str(payload.get("source_bundle_sha256") or "")
        if len(source_bundle_sha256) != 64:
            raise FundingSourceSnapshotEmissionError(
                f"source snapshot bundle digest invalid: {source_bundle_sha256!r}"
            )
        snapshot_path = (
            db_path.parent
            / "funding_source_snapshots"
            / f"funding_source_snapshot_v1_{source_bundle_sha256}.json"
        )

        _write_json_atomic(snapshot_path, envelope)
        return FundingSourceSnapshotReference(
            path=snapshot_path,
            file_sha256=sha256_file(snapshot_path),
            source_bundle_sha256=source_bundle_sha256,
            schema_version=str(payload.get("schema_version") or ""),
            write_state=str(payload.get("write_state") or ""),
            created_at=str(payload.get("generated_at_utc") or ""),
            envelope=envelope,
        )
    except FundingSourceSnapshotEmissionError:
        raise
    except Exception as exc:
        raise FundingSourceSnapshotEmissionError(
            f"{type(exc).__name__}: {exc}"
        ) from exc


def _committed_funding_source_snapshot_reference(
    pending_ref: FundingSourceSnapshotReference,
    *,
    batch_id: int,
) -> FundingSourceSnapshotReference:
    payload = dict(pending_ref.envelope["snapshot_payload"])
    metadata = dict(payload.get("snapshot_metadata") or {})
    metadata.update(
        {
            "write_state": "committed",
            "ledger_batch_id": str(batch_id),
            "batch_identity_matches": True,
        }
    )
    payload["write_state"] = "committed"
    payload["snapshot_metadata"] = metadata
    envelope = build_funding_source_snapshot_envelope_v1(payload)
    validation_reasons = validate_funding_source_snapshot_envelope_v1(envelope)
    if validation_reasons:
        raise FundingSourceSnapshotEmissionError(
            "committed source snapshot envelope validation failed: "
            + ", ".join(validation_reasons)
        )

    _write_json_atomic(pending_ref.path, envelope)
    return FundingSourceSnapshotReference(
        path=pending_ref.path,
        file_sha256=sha256_file(pending_ref.path),
        source_bundle_sha256=str(payload.get("source_bundle_sha256") or ""),
        schema_version=str(payload.get("schema_version") or ""),
        write_state="committed",
        created_at=str(payload.get("generated_at_utc") or ""),
        envelope=envelope,
    )


def _mark_funding_source_snapshot_db_reference_committed(
    *,
    db_path: Path,
    batch_id: int,
    committed_ref: FundingSourceSnapshotReference,
) -> None:
    conn = connect_writer(db_path)
    try:
        _update_batch_snapshot_reference(conn, batch_id, committed_ref)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Main entry point.
# ---------------------------------------------------------------------------

def run_sqlite_accounting(
    db_path: str | Path | None = None,
    forward_obs_dir: Path | None = None,
    data_dir: Path | None = None,
) -> tuple[int, str]:
    """Run one SQLite paper accounting pass.

    Args:
        db_path: Path to the SQLite ledger DB. Uses get_paper_db_path() if None.
        forward_obs_dir: Path to observation_log.json directory.
        data_dir: Path to data directory for OHLCV/funding CSVs.
                    Patches quantbot.data.multi_asset_loader._DATA_DIR
                    and quantbot.data.funding_loader._DATA_DIR so the
                    existing load_all_ohlcv/load_all_funding helpers read
                    from the specified directory.

    Returns (status_code, status_message).

    Status codes:
      0  OK
      2  ABORTED
      3  CONFIG_ERROR
      4  CORRUPT_LEDGER
      5  PRE_START
      6  LEDGER_BUSY
    """
    db_path = get_paper_db_path(db_path)
    obs_dir = forward_obs_dir or default_forward_obs_dir()
    now = _now()
    created_at = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    # === PATCH DATA_DIR INTO EXISTING LOADERS =========================
    if data_dir is not None:
        import quantbot.data.multi_asset_loader as _ma
        import quantbot.data.funding_loader as _fl
        _orig_multi = _ma._DATA_DIR
        _orig_funding = _fl._DATA_DIR
        _ma._DATA_DIR = Path(data_dir)
        _fl._DATA_DIR = Path(data_dir)
    else:
        _orig_multi = None
        _orig_funding = None

    try:
        # === CONFIG (fail closed) =================================================
        try:
            # Resolve the paper config dir via paper_output_dir() so the writer honors
            # QNTY_PAPER_OUTPUT_DIR (testability seam). Production default is unchanged:
            # paper_output_dir() returns /srv/qnty/output/paper_pnl_v1 when the env is unset.
            config = load_config(paper_output_dir())
        except Exception as exc:
            return STATUS_CONFIG_ERROR, f"Config error: {exc}"

        # === CONNECT + BEGIN IMMEDIATE =========================================
        try:
            conn = connect_writer(db_path, timeout=5.0)
        except Exception as exc:
            return STATUS_CONFIG_ERROR, f"DB connection failed: {exc}"

        try:
            # Try BEGIN IMMEDIATE; if it fails, DB is locked by another writer
            try:
                conn.execute("BEGIN IMMEDIATE")
            except sqlite3.OperationalError as exc:
                conn.close()
                msg = str(exc).lower()
                if "lock" in msg or "busy" in msg:
                    return STATUS_LEDGER_BUSY, f"Could not acquire write lock: {exc}"
                return STATUS_CONFIG_ERROR, f"BEGIN IMMEDIATE failed: {exc}"

            # === RE-READ DB CONFIG + STATE INSIDE TRANSACTION =====================
            try:
                db_config = validate_database_identity(conn)
            except Exception as exc:
                conn.rollback()
                conn.close()
                return STATUS_CONFIG_ERROR, f"DB identity invalid: {exc}"

            fs_identity = (
                config.get("forward_start_ts"),
                config.get("config_hash"),
            )
            db_identity = (
                db_config.get("forward_start_ts"),
                db_config.get("config_hash"),
            )
            if fs_identity != db_identity:
                conn.rollback()
                conn.close()
                return (
                    STATUS_CONFIG_ERROR,
                    "Filesystem paper_config.json identity does not match SQLite paper_config "
                    f"(filesystem forward_start_ts/config_hash={fs_identity!r}, "
                    f"database={db_identity!r})",
                )

            state_row = conn.execute("SELECT * FROM ledger_state WHERE id = 1").fetchone()
            if state_row is None:
                conn.rollback()
                conn.close()
                return STATUS_CORRUPT_LEDGER, "ledger_state row (id=1) not found"

            watermark = state_row["watermark_bar_ts"] or ""
            acc = {
                "realized_gross": state_row["realized_gross"],
                "fees_cum": state_row["fees_cum"],
                "funding_cum": state_row["funding_cum"],
            }
            peak_equity = state_row["peak_equity"] or float(config.get("initial_equity_usd", 10000.0))

            forward_start_ts = db_config["forward_start_ts"]
            initial_equity = float(db_config["initial_equity_usd"])
            notional = float(db_config.get("notional_usd", 1000.0))
            fee_bps = float(db_config.get("fee_bps", 5.0))
            engine_version = DB_PAPER_ENGINE_VERSION
            cfg_hash = db_config["config_hash"]

            # === LOAD INPUTS =========================================================
            obs_path = obs_dir / "observation_log.json"
            if not obs_path.exists():
                conn.rollback()
                conn.close()
                return STATUS_ABORTED, f"observation_log.json not found: {obs_path}"

            try:
                with open(obs_path, encoding="utf-8") as fh:
                    obs_log = json.load(fh)
            except Exception as exc:
                conn.rollback()
                conn.close()
                return STATUS_ABORTED, f"Malformed observation_log.json: {exc}"

            # Freshness gate
            freshness_cfg = config.get("freshness", {})
            fresh = check_freshness(
                obs_path, obs_log, obs_dir, now, freshness_cfg,
                forward_start_ts=forward_start_ts,
            )
            if fresh.aborted:
                conn.rollback()
                conn.close()
                return STATUS_ABORTED, f"{fresh.code}: {fresh.reason}"

            if fresh.code == "NO_ELIGIBLE_BARS_YET":
                conn.rollback()
                conn.close()
                return STATUS_PRE_START, fresh.reason

            per_bar_obs = obs_log.get("per_bar_obs", [])

            # === DIVERGENCE CHECK (missing from initial implementation) =============
            # Read existing signal snapshots from DB for divergence check
            existing_snapshots = [
                dict(row)
                for row in conn.execute(
                    """
                    SELECT ss.* FROM signal_snapshots ss
                    JOIN ledger_events e ON e.seq = ss.seq
                    ORDER BY ss.bar_ts
                    """
                ).fetchall()
            ]
            divergence = check_divergence(existing_snapshots, per_bar_obs)
            if divergence:
                conn.rollback()
                conn.close()
                return STATUS_ABORTED, f"SIGNAL_SNAPSHOT_DIVERGENCE: {divergence}"

            # Build state dict for engine (matching JSONL runner)
            engine_state: dict[str, Any] = {
                "watermark_bar_ts": watermark,
                "open_positions": {
                    row["symbol"]: dict(row)
                    for row in conn.execute("SELECT * FROM open_positions").fetchall()
                },
                "accumulators": acc,
                "peak_equity": peak_equity,
                "bars_elapsed": 0,
            }
            # Snapshot the open book BEFORE the engine mutates it — needed to seed
            # the per-bar position snapshots for a restart batch.
            prior_open_positions = {
                sym: dict(pos) for sym, pos in engine_state["open_positions"].items()
            }

            # Load market data (using patched data_dir if provided)
            bars_by_symbol: dict[str, list[Bar]] | None = load_all_ohlcv()
            funding_df = load_all_funding()

            # Build engine config (matching config.py build_config output)
            engine_config: dict[str, Any] = {
                "forward_start_ts": forward_start_ts,
                "initial_equity_usd": initial_equity,
                "notional_usd": notional,
                "leverage": db_config.get("leverage", 1.0),
                "fee_model": {"type": "flat_taker", "fee_bps": fee_bps},
                "slippage_model": {
                    "type": "fixed",
                    "slippage_bps": db_config.get("slippage_bps", 5.0),
                },
                "funding_model": {
                    "type": db_config.get("funding_type", "accrual"),
                    "applied_as": db_config.get("funding_applied_as", "cash_flow"),
                },
                "fill_model": db_config.get("fill_model", "next_bar_open_pessimistic"),
                "signal_source": db_config.get("signal_source", "observation_log.json:per_bar_obs"),
                "engine_version": engine_version,
                "config_hash": cfg_hash,
                "freshness": freshness_cfg,
            }

            # === RUN ENGINE (pure compute; writes NOTHING to SQLite) ============
            # run_engine is a pure function over (config, obs, bars, funding_df, state):
            # it returns an EngineResult of in-memory row lists and never touches `conn`
            # or any DB. All SQLite mutation happens below in _insert_ledger_batch and
            # the row inserts, so a gate placed between this call and those inserts can
            # abort with the engine's exact verdict yet leave the ledger untouched.
            result = run_engine(engine_config, per_bar_obs, bars_by_symbol, funding_df, engine_state)

            # === POST-ENGINE FUNDING-COVERAGE GATE (fail closed BEFORE any insert) ===
            # load_all_funding() SILENTLY SKIPS any symbol whose CSV is absent, so a
            # missing source funding window reaches the engine as a held interval with
            # NO funding event — which the engine records as rate_available=False /
            # funding_amount=0.0 (a silent zero the verifier can only CAVEAT after the
            # batch is already committed). We fail CLOSED on that here, before mutation.
            #
            # The engine is the single authority on which windows actually REQUIRE
            # funding: the main loop skips when eff_start >= ts (entry/deferred/
            # zero-held bars emit no row at all), so this gate can never over-fire on a
            # legitimate deferral (it falls through to the PRE_START path below).
            #
            # A funding row counts as required-but-missing ONLY when it has a positive
            # holding interval AND no source event: window_start < window_end AND
            # rate_available == False. The right-open/degenerate exit-tail stub emits a
            # row over (ts, exit_fill_ts] whose end can resolve to a NON-future bar when
            # the exit cannot fill yet (window_end <= window_start) — an empty interval
            # that charges zero funding and is NOT a missing source, so it is excluded.
            # Duration is compared on PARSED UTC datetimes via parse_bar_utc (the single
            # repo timestamp helper, also used by the freshness/divergence paths) — never
            # a lexicographic string compare, which QNTY forbids because a naive string
            # sorts before its own trailing-Z form. A missing-funding row whose timestamps
            # do NOT parse cannot be proven a benign degenerate stub, so it fails CLOSED
            # (counted as required-but-missing -> abort), never a silent pass. This is the
            # same rate_available signal the SQLite verifier coverage stamp keys on,
            # keeping writer abort and verifier caveat consistent.
            #
            # Mutation safety: no INSERT/UPDATE and no watermark advance has run yet
            # (the BEGIN IMMEDIATE above only holds the write lock). We roll back and
            # close exactly like the freshness/divergence/empty-result abort paths, so
            # the lock is released with ZERO writes.
            required_funding_rows = []
            missing_funding = []
            for f in result.funding:
                try:
                    positive_duration = parse_bar_utc(
                        str(f.get("window_start", ""))
                    ) < parse_bar_utc(str(f.get("window_end", "")))
                except (TypeError, ValueError):
                    # Unparseable timestamp on a missing-funding row -> fail closed.
                    positive_duration = True
                if not positive_duration:
                    continue
                required_funding_rows.append(f)
                if not f.get("rate_available", True):
                    missing_funding.append(f)
            if missing_funding:
                miss = ", ".join(
                    f'{f["symbol"]}@{f["window_start"]}' for f in missing_funding[:5]
                )
                suffix = (
                    "" if len(missing_funding) <= 5
                    else f" (+{len(missing_funding) - 5} more)"
                )
                conn.rollback()
                conn.close()
                return (
                    STATUS_ABORTED,
                    f"FUNDING_COVERAGE_MISSING: engine accrued {len(missing_funding)} "
                    f"funding interval(s) with no source funding event; missing: "
                    f"{miss}{suffix}; aborting before ledger mutation.",
                )

            try:
                source_coverage = check_funding_coverage_from_source_rows(
                    required_funding_rows,
                    funding_df,
                )
            except Exception as exc:
                conn.rollback()
                conn.close()
                return (
                    STATUS_ABORTED,
                    "FUNDING_COVERAGE_MISSING: funding-source coverage check "
                    f"failed before ledger mutation: {type(exc).__name__}: {exc}",
                )
            if source_coverage.missing_windows:
                miss = ", ".join(
                    f"{row.symbol}@{row.window_start}:source_issue="
                    f"{row.source_issue or 'rate_unavailable'}"
                    for row in source_coverage.missing_windows[:5]
                )
                suffix = (
                    "" if len(source_coverage.missing_windows) <= 5
                    else f" (+{len(source_coverage.missing_windows) - 5} more)"
                )
                conn.rollback()
                conn.close()
                return (
                    STATUS_ABORTED,
                    "FUNDING_COVERAGE_MISSING: source funding coverage incomplete "
                    "for engine-required interval(s); missing/ambiguous: "
                    f"{miss}{suffix}; aborting before ledger mutation.",
                )

            if not result.equity:
                # No bar produced an equity snapshot this run — either everything
                # is up to date or the next eligible bar deferred on a missing T+1
                # open. Either way there is nothing to commit; never write an empty
                # batch (the verifier treats a committed empty batch as CORRUPT).
                conn.rollback()
                conn.close()
                if state_row["watermark_bar_ts"] is None:
                    return STATUS_PRE_START, "No committed eligible bars yet"
                return STATUS_OK, "No new bars to process"

            # === GIT-SHA PROVENANCE GATE (fail closed BEFORE any insert) ==========
            # Every committed ledger_batches row must self-attest which code produced
            # it. resolve_git_sha() returns a full 40-hex HEAD SHA rooted at the repo
            # working tree, or None if git cannot be resolved deterministically. We
            # NEVER persist a new batch with git_sha=None (the historical provenance
            # gap the verifier now caveats): if the SHA is unresolved we abort here,
            # before _insert_ledger_batch / any watermark advance, rolling back and
            # closing exactly like the funding-coverage / freshness abort paths so the
            # write lock is released with ZERO writes. Old git_sha=None rows already on
            # disk are untouched and remain readable historical evidence.
            batch_git_sha = resolve_git_sha()
            if batch_git_sha is None:
                conn.rollback()
                conn.close()
                return (
                    STATUS_ABORTED,
                    "GIT_SHA_UNRESOLVED: could not resolve repo HEAD (git rev-parse "
                    "HEAD) for batch provenance; aborting before ledger mutation rather "
                    "than committing an unprovenanced batch.",
                )

            snapshot_batch_end_watermark = max(
                eq["bar_ts"] for eq in result.equity
            )
            try:
                snapshot_ref = _emit_pending_funding_source_snapshot(
                    conn=conn,
                    db_path=db_path,
                    db_config=db_config,
                    state_row=state_row,
                    required_funding_rows=required_funding_rows,
                    funding_df=funding_df,
                    data_dir=data_dir,
                    created_at=created_at,
                    batch_git_sha=batch_git_sha,
                    batch_end_watermark=snapshot_batch_end_watermark,
                )
            except FundingSourceSnapshotEmissionError as exc:
                conn.rollback()
                conn.close()
                return (
                    STATUS_ABORTED,
                    "FUNDING_SOURCE_SNAPSHOT_EMISSION_FAILED: "
                    f"{exc}; aborting before ledger mutation.",
                )

            # === INSERT INTO DB INSIDE TRANSACTION ==========================
            # New-lane DBs stamp every batch with paper_config.lane_id so each batch
            # self-attests its lane (LEDGER_BATCH_LANE_STAMPING_PHASE3_PLAN). db_config
            # is the paper_config row re-read inside this transaction; .get() returns
            # None for a baseline row (NULL lane_id) or a legacy row lacking the column,
            # which routes _insert_ledger_batch to the byte-identical baseline INSERT.
            batch_lane_id = db_config.get("lane_id")
            batch_id = _insert_ledger_batch(
                conn,
                created_at=created_at,
                started_at=created_at,
                prior_watermark=watermark or None,
                paper_engine_version=engine_version,
                config_hash_val=cfg_hash,
                lane_id=batch_lane_id,
            )
            _update_batch_snapshot_reference(conn, batch_id, snapshot_ref)

            # Build the event chain for all new rows
            processed_bar_ts = {eq["bar_ts"] for eq in result.equity}

            # Build per-bar data (seeded with the restart open book)
            bars_data = _group_engine_result_by_bar(
                result, per_bar_obs, engine_version, cfg_hash, prior_open_positions
            )

            # Build signal snapshots list
            all_signal_snapshots = _build_signal_snapshots_for_bars(
                per_bar_obs, processed_bar_ts, engine_version, cfg_hash
            )
            snapshot_by_ts: dict[str, dict] = {}
            for snap in all_signal_snapshots:
                snapshot_by_ts[snap["bar_ts"]] = snap

            # Collect all events across all bars, sorted
            all_funding: list[dict] = []
            all_fills: list[dict] = []
            all_trades: list[dict] = []
            all_position_snapshots: list[dict] = []
            all_equity_snapshots: list[dict] = []

            for bar_dict in bars_data:
                ts = bar_dict["bar_ts"]
                all_funding.extend(bar_dict["funding"])
                all_fills.extend(bar_dict["fills"])
                all_trades.extend(bar_dict["trades"])
                if bar_dict["position_snapshot"]:
                    all_position_snapshots.append(bar_dict["position_snapshot"])
                if bar_dict["equity_snapshot"]:
                    all_equity_snapshots.append(bar_dict["equity_snapshot"])

            # Sort into event chain
            event_chain = _sort_events_for_chain(
                all_signal_snapshots,
                all_funding,
                all_fills,
                all_trades,
                all_position_snapshots,
                all_equity_snapshots,
            )

            # Insert ledger_events (first pass)
            # Keyed by (event_type, event_key): an exit fill and its closing
            # trade share the same id, so the bare key is not unique.
            event_seq_by_key: dict[tuple[str, str], int] = {}
            prev_seq: int | None = None

            # Get the max seq so far (for prev_seq chaining across batches)
            max_seq_row = conn.execute(
                "SELECT seq FROM ledger_events ORDER BY seq DESC LIMIT 1"
            ).fetchone()
            if max_seq_row:
                prev_seq = max_seq_row["seq"]

            for event_type, attrs in event_chain:
                event_key = _event_key(event_type, **attrs)
                cur = conn.execute(
                    """
                    INSERT INTO ledger_events (
                        batch_id, event_type, event_key, recorded_at,
                        bar_ts, symbol, prev_seq
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        batch_id,
                        event_type,
                        event_key,
                        created_at,
                        _event_bar_ts(event_type, attrs),
                        attrs.get("symbol"),
                        prev_seq,
                    ),
                )
                seq = cur.lastrowid
                event_seq_by_key[(event_type, event_key)] = seq
                prev_seq = seq

            # Insert typed rows (second pass)
            # Reconstruct open_positions as we walk bars
            replay_positions: dict[str, dict] = {
                row["symbol"]: dict(row)
                for row in conn.execute("SELECT * FROM open_positions").fetchall()
            }
            close_by_symbol_ts = {
                sym: {bar.timestamp: bar.close for bar in bars}
                for sym, bars in bars_by_symbol.items()
            }

            for bar_dict in bars_data:
                ts = bar_dict["bar_ts"]
                commit_id = bar_dict["bar_commit_id"]

                # signal snapshots for this bar
                snap = snapshot_by_ts.get(ts)
                snap_rows = [snap] if snap else []

                # funding/fills/trades for this bar
                fund_rows = bar_dict["funding"]
                fill_rows = bar_dict["fills"]
                trade_rows = bar_dict["trades"]

                # position snapshot (pre-fill book)
                pos_snap = bar_dict["position_snapshot"]

                # equity snapshot
                eq_row = bar_dict["equity_snapshot"]

                _insert_typed_rows_for_bar(
                    conn, batch_id, ts, commit_id, result,
                    event_seq_by_key,
                    snap_rows, fund_rows, fill_rows, trade_rows,
                    pos_snap,
                    eq_row,
                    _snapshot_positions_with_unrealized(
                        replay_positions, close_by_symbol_ts, ts
                    ),
                )

                # Apply fills to replay_positions (post-snapshot)
                for fl in fill_rows:
                    sym = fl["symbol"]
                    if fl["kind"] == "entry":
                        replay_positions[sym] = {
                            "entry_fill_id": fl["fill_id"],
                            "entry_price": fl["fill_price"],
                            "qty": fl["qty"],
                            "entry_bar_ts": ts,
                            "entry_fill_ts": fl["fill_ts"],
                            "funding_accrued": 0.0,
                            "entry_fee": fl["fee"],
                            "hold_bars": 0,
                            "unrealized_gross": 0.0,
                        }
                    elif fl["kind"] == "exit":
                        replay_positions.pop(sym, None)

            # === UPDATE LEDGER_STATE =============================================
            new_watermark = watermark
            if result.equity:
                new_watermark = max(eq["bar_ts"] for eq in result.equity)

            # Update accumulators from engine state
            final_acc = engine_state["accumulators"]
            final_peak = engine_state["peak_equity"]

            conn.execute(
                """
                UPDATE ledger_state
                SET watermark_bar_ts = ?,
                    realized_gross = ?,
                    fees_cum = ?,
                    funding_cum = ?,
                    peak_equity = ?,
                    updated_at = ?
                WHERE id = 1
                """,
                (
                    new_watermark or None,
                    final_acc.get("realized_gross", 0.0),
                    final_acc.get("fees_cum", 0.0),
                    final_acc.get("funding_cum", 0.0),
                    final_peak,
                    created_at,
                ),
            )

            # === UPDATE OPEN_POSITIONS (delete all, re-insert) =====================
            # Persist the engine's authoritative open book (NOT the entry/exit
            # replay): the engine carries the per-bar funding_accrued, hold_bars
            # and entry_fee the exit path needs to resume the position losslessly
            # across runs. The replay only knows fills and would store 0 for
            # funding/hold and lose entry_fee.
            final_open_positions = engine_state["open_positions"]
            conn.execute("DELETE FROM open_positions")
            for sym, pos in final_open_positions.items():
                # The engine's authoritative open book MUST carry the fields the
                # exit path needs to resume a position losslessly across runs. A
                # missing entry_fee / funding_accrued / hold_bars is an internal
                # accounting bug, NOT a tolerable default: persisting a silent 0.0
                # would corrupt a later exit's fee/funding/hold arithmetic. Fail
                # closed so the whole batch rolls back (CORRUPT_LEDGER).
                for _field in ("entry_fee", "funding_accrued", "hold_bars"):
                    if _field not in pos:
                        raise ValueError(
                            f"open position {sym!r} is missing required field "
                            f"{_field!r} in the engine open book; refusing to "
                            f"persist a silent default"
                        )
                conn.execute(
                    """
                    INSERT INTO open_positions (
                        symbol, entry_fill_id, entry_price, qty,
                        entry_bar_ts, entry_fill_ts, entry_fee,
                        funding_accrued, hold_bars
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        sym,
                        pos["entry_fill_id"],
                        pos["entry_price"],
                        pos["qty"],
                        pos["entry_bar_ts"],
                        pos["entry_fill_ts"],
                        pos["entry_fee"],
                        pos["funding_accrued"],
                        pos["hold_bars"],
                    ),
                )

            # === RECONCILE INSIDE TRANSACTION (BEFORE COMMIT) =====================
            event_count = len(event_chain)
            typed_counts: dict[str, int] = {}
            for et, _ in event_chain:
                typed_counts[et] = typed_counts.get(et, 0) + 1

            # Pass the PRIOR committed peak (read from ledger_state before the engine ran), not
            # final_peak: check 11 replays the running max over this batch's equity rows starting
            # from that prior peak, exactly as the engine does, so a dip below an earlier batch's
            # high reconciles instead of false-CORRUPTing. (For the first batch the prior peak is
            # initial_equity.)
            recon_failures = _reconcile_batch_inside_tx(
                conn, batch_id, event_count, event_chain,
                typed_counts, final_open_positions,
                final_acc, peak_equity, initial_equity, fee_bps,
            )

            if recon_failures:
                conn.rollback()
                conn.close()
                return (
                    STATUS_CORRUPT_LEDGER,
                    f"Reconciliation failed: {'; '.join(recon_failures[:3])}",
                )

            # === UPDATE BATCH AS COMMITTED ========================================
            first_seq = None
            last_seq = None
            if event_chain:
                first_et, first_attrs = event_chain[0]
                last_et, last_attrs = event_chain[-1]
                first_seq = event_seq_by_key.get(
                    (first_et, _event_key(first_et, **first_attrs))
                )
                last_seq = event_seq_by_key.get(
                    (last_et, _event_key(last_et, **last_attrs))
                )

            committed_bar_count = len(result.equity) if result.equity else 0

            _update_batch_on_commit(
                conn, batch_id,
                committed_at=created_at,
                new_watermark=new_watermark or None,
                first_event_seq=first_seq,
                last_event_seq=last_seq,
                event_count=event_count,
                committed_bar_count=committed_bar_count,
                git_sha=batch_git_sha,
            )

            # === COMMIT ============================================================
            conn.commit()
            conn.close()

            committed_msg = (
                f"Committed batch {batch_id}: {committed_bar_count} bars, "
                f"{event_count} events"
            )
            try:
                committed_snapshot_ref = _committed_funding_source_snapshot_reference(
                    snapshot_ref,
                    batch_id=batch_id,
                )
            except Exception as exc:
                return STATUS_OK, (
                    f"{committed_msg}; FUNDING_SOURCE_SNAPSHOT_COMMIT_MARKER_FAILED: "
                    f"{type(exc).__name__}: {exc}; batch remains "
                    "CAVEATED_ENGINE_SEMANTICS."
                )

            try:
                _mark_funding_source_snapshot_db_reference_committed(
                    db_path=db_path,
                    batch_id=batch_id,
                    committed_ref=committed_snapshot_ref,
                )
            except Exception as exc:
                return STATUS_OK, (
                    f"{committed_msg}; "
                    "FUNDING_SOURCE_SNAPSHOT_DB_REFERENCE_COMMIT_MARK_FAILED: "
                    f"{type(exc).__name__}: {exc}; batch remains "
                    "CAVEATED_ENGINE_SEMANTICS."
                )

            return STATUS_OK, committed_msg

        except Exception as exc:
            try:
                conn.rollback()
            except Exception:
                pass
            try:
                conn.close()
            except Exception:
                pass
            return STATUS_CORRUPT_LEDGER, f"Unhandled error: {type(exc).__name__}: {exc}"

    finally:
        # Restore original _DATA_DIR if we patched it
        if data_dir is not None and _orig_multi is not None:
            import quantbot.data.multi_asset_loader as _ma
            import quantbot.data.funding_loader as _fl
            _ma._DATA_DIR = _orig_multi
            _fl._DATA_DIR = _orig_funding


# ---------------------------------------------------------------------------
# Module-level exports.
# ---------------------------------------------------------------------------

__all__ = [
    "STATUS_OK",
    "STATUS_ABORTED",
    "STATUS_CONFIG_ERROR",
    "STATUS_CORRUPT_LEDGER",
    "STATUS_PRE_START",
    "STATUS_LEDGER_BUSY",
    "run_sqlite_accounting",
]
