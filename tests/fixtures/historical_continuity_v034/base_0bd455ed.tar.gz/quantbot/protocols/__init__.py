"""Protocol interfaces for QuantBot."""
