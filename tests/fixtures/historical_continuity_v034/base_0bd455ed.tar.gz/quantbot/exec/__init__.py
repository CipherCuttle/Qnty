"""Execution layer for QuantBot."""
