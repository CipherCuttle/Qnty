"""Tests for quantbot/experiment/offline_edge_validation_cli.py

PR A — safe skeleton CLI tests.  No exchange, engine, DB, or paper imports.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
import pathlib

import pytest

from quantbot.experiment.offline_edge_input_manifest import (
    discover_input_files,
    compute_input_manifest_fingerprint,
)

CLI_MODULE = "quantbot.experiment.offline_edge_validation_cli"

FIXTURE_DIR = Path(
    "tests/fixtures/edge_validation_golden"
).resolve()


def _run_cli(*args: str) -> subprocess.CompletedProcess:
    """Run the CLI module with given args, return CompletedProcess."""
    cmd = [sys.executable, "-m", CLI_MODULE] + list(args)
    return subprocess.run(cmd, capture_output=True, text=True)


# ---------------------------------------------------------------------------
# Test classes
# ---------------------------------------------------------------------------


class TestRefusesWithoutReadOnly:
    def test_refuses_without_read_only(self) -> None:
        """Missing --read-only should exit non-zero with message containing --read-only."""
        result = _run_cli("--output-dir", "/tmp/test_skeleton")
        assert result.returncode != 0
        # argparse writes to stderr
        assert "--read-only" in result.stderr or "--read-only" in result.stdout


class TestRefusesProdPaths:
    def test_refuses_srv_qnty_output(self) -> None:
        # NOT under /tmp → allowlist check fires first with FATAL
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/srv/qnty/output/paper_pnl_v1",
        )
        assert result.returncode == 3
        assert "must be under" in result.stdout

    def test_refuses_srv_qnty_prefix(self) -> None:
        # NOT under /tmp → allowlist check fires first with FATAL
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/srv/qnty/anything/else",
        )
        assert result.returncode == 3
        assert "must be under" in result.stdout

    def test_refuses_official_report_path(self) -> None:
        """Test with a path that contains official report pattern.
        Path IS under /tmp, so allowlist passes; caught by pattern check."""
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/some/path/paper_verify_report.json",
        )
        assert result.returncode == 3
        assert "official report" in result.stdout


class TestRefusesProdPathsOnFixtureDirs:
    def test_refuses_bars_dir_prod(self) -> None:
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--bars-dir",
            "/srv/qnty/data/bars",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_refuses_funding_dir_prod(self) -> None:
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--funding-dir",
            "/srv/qnty/data/funding",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_refuses_manifest_dir_official_report(self) -> None:
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--manifest-dir",
            "/tmp/data/official_report/v1",
        )
        assert result.returncode == 3
        assert "official report" in result.stdout


class TestAcceptsTmpOutput:
    def test_accepts_tmp_output_with_fixtures(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create actual fixture directories with at least one file
            bars_dir = os.path.join(tmpdir, "bars")
            funding_dir = os.path.join(tmpdir, "funding")
            manifest_dir = os.path.join(tmpdir, "manifest")
            os.makedirs(bars_dir)
            os.makedirs(funding_dir)
            os.makedirs(manifest_dir)
            # Write dummy fixture files so CLI can discover them
            with open(os.path.join(bars_dir, "bars.csv"), "w") as f:
                f.write("timestamp,open,high,low,close,volume\n")
            with open(os.path.join(funding_dir, "funding.csv"), "w") as f:
                f.write("timestamp,funding_rate\n")

            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--bars-dir",
                bars_dir,
                "--funding-dir",
                funding_dir,
                "--manifest-dir",
                manifest_dir,
            )
            assert result.returncode == 0
            receipt_path = os.path.join(tmpdir, "validation_receipt.json")
            assert os.path.exists(receipt_path)


class TestReceiptContents:
    def test_receipt_contains_required_keys(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
            )
            assert result.returncode == 0
            receipt_path = os.path.join(tmpdir, "validation_receipt.json")
            with open(receipt_path) as f:
                receipt = json.load(f)
            assert "validation_receipt" in receipt
            assert "input_manifest_fingerprint" in receipt
            assert "cost_model_assumptions" in receipt
            assert "per_stage_metrics" in receipt
            assert "final_verdict" in receipt

    def test_final_verdict_is_skeleton_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
            )
            assert result.returncode == 0
            receipt_path = os.path.join(tmpdir, "validation_receipt.json")
            with open(receipt_path) as f:
                receipt = json.load(f)
            assert receipt["final_verdict"] in ("SKELETON_ONLY", "INCONCLUSIVE")
            assert receipt["final_verdict"] != "EDGE_CANDIDATE"

    def test_receipt_tool_name_is_offline_edge_validation(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
            )
            assert result.returncode == 0
            receipt_path = os.path.join(tmpdir, "validation_receipt.json")
            with open(receipt_path) as f:
                receipt = json.load(f)
            assert receipt["validation_receipt"]["tool_name"] == "offline_edge_validation"


class TestCostModelAssumptionsInReceipt:
    """PR C — receipt carries fixture-only cost-model assumptions, no PnL."""

    def _receipt(self, tmpdir: str) -> dict:
        result = _run_cli("--read-only", "--output-dir", tmpdir)
        assert result.returncode == 0
        with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
            return json.load(f)

    def test_receipt_includes_cost_model_assumptions(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            cma = self._receipt(tmpdir)["cost_model_assumptions"]
            assert cma["commission_bps_per_side"] == 5.0
            assert cma["slippage_bps_per_side"] == 5.0
            assert cma["spread_bps_per_side"] == 1.0
            assert cma["cost_model_version"] == "1.0"
            assert cma["funding_cost_placeholder"] == 0.0

    def test_receipt_has_no_pnl_or_edge_keys(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            receipt = self._receipt(tmpdir)
            # Cost-model PR must not introduce strategy performance / edge output.
            for forbidden in ("pnl", "strategy_performance", "edge_candidate", "returns"):
                assert forbidden not in receipt
            assert receipt["final_verdict"] == "SKELETON_ONLY"


class TestNoExchangeModules:
    def test_no_exchange_modules_imported(self) -> None:
        """Verify that importing the CLI doesn't pull in exchange modules."""
        spec = importlib.util.find_spec(
            "quantbot.experiment.offline_edge_validation_cli"
        )
        assert spec is not None

        check_script = (
            "import sys; "
            "sys.modules.pop('quantbot.experiment.offline_edge_validation_cli', None); "
            "from quantbot.experiment.offline_edge_validation_cli import main; "
            "mods = [m for m in sys.modules.keys() "
            "       if 'exchange' in m or 'ccxt' in m]; "
            "print(f'EXCHANGE_MODS:{mods}'); "
            "assert not mods, f'Exchange modules found: {mods}'"
        )
        result = subprocess.run(
            [sys.executable, "-c", check_script],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, (
            f"Exchange import check failed: {result.stderr}"
        )


class TestFixtureSha256Unchanged:
    def test_fixture_sha256_unchanged(self) -> None:
        """Verify test fixture SHAs are unchanged - placeholder for future fixtures."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a dummy fixture file
            fixture_file = os.path.join(tmpdir, "test_bars.csv")
            with open(fixture_file, "w") as f:
                f.write("timestamp,open,high,low,close,volume\n")

            sha_before = hashlib.sha256(
                open(fixture_file, "rb").read()
            ).hexdigest()

            output_dir = os.path.join(tmpdir, "output")
            os.makedirs(output_dir)

            result = _run_cli(
                "--read-only",
                "--output-dir",
                output_dir,
                "--bars-dir",
                tmpdir,
            )
            assert result.returncode == 0

            sha_after = hashlib.sha256(
                open(fixture_file, "rb").read()
            ).hexdigest()
            assert sha_before == sha_after, (
                "Fixture file was mutated by CLI run"
            )


class TestRefusesNonTempOutput:
    def test_refuses_output_outside_tmp(self) -> None:
        """--output-dir outside /tmp should be refused by positive allowlist."""
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/home/swirky/qnty-test-output",
        )
        assert result.returncode == 3
        assert "must be under" in result.stdout or "/tmp" in result.stdout

    def test_refuses_path_traversal_to_srv_qnty(self) -> None:
        """Path traversal /tmp/../../srv/qnty/... resolves to /srv/qnty/... and is refused."""
        import os
        traversal_path = os.path.join("/tmp", "..", "..", "srv", "qnty", "output")
        result = _run_cli(
            "--read-only",
            "--output-dir",
            traversal_path,
        )
        # After realpath resolution: /tmp/../../srv/qnty/output -> /srv/qnty/output
        # Refused by allowlist (not under /tmp) and/or prod-path check
        assert result.returncode == 3
        assert "Refusing" in result.stdout or "must be under" in result.stdout

    def test_refuses_path_traversal_outside_tmp(self) -> None:
        """Path traversal /tmp/../etc -> resolves to /etc, not under /tmp."""
        import os
        traversal_path = os.path.join("/tmp", "..", "etc", "qnty-test")
        result = _run_cli(
            "--read-only",
            "--output-dir",
            traversal_path,
        )
        # After realpath: /tmp/../etc -> /etc, refused by allowlist
        assert result.returncode == 3


class TestRefusesTmpBoundaryBypass:
    """Output paths that look like /tmp but are not actually under /tmp."""

    def test_refuses_tmp_evil(self) -> None:
        result = _run_cli("--read-only", "--output-dir", "/tmp_evil")
        assert result.returncode == 3
        assert "must be under" in result.stdout or "/tmp" in result.stdout

    def test_refuses_tmp123(self) -> None:
        result = _run_cli("--read-only", "--output-dir", "/tmp123")
        assert result.returncode == 3
        assert "must be under" in result.stdout

    def test_refuses_tmp_not_actually_tmp(self) -> None:
        result = _run_cli("--read-only", "--output-dir", "/tmp-not-actually-tmp")
        assert result.returncode == 3
        assert "must be under" in result.stdout

    def test_accepts_tmp_nested_output(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                os.path.join(tmpdir, "qnty-valid-output"),
            )
            assert result.returncode == 0
            receipt_path = os.path.join(tmpdir, "qnty-valid-output", "validation_receipt.json")
            assert os.path.exists(receipt_path)


class TestInputManifestFingerprint:
    """Tests for input_manifest_fingerprint in CLI output."""

    def test_cli_with_fixture_dirs_writes_non_placeholder_fingerprint(self) -> None:
        """CLI with fixture dirs computes real fingerprint (not PLACEHOLDER)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--bars-dir",
                str(FIXTURE_DIR),
                "--funding-dir",
                str(FIXTURE_DIR),
                "--manifest-dir",
                str(FIXTURE_DIR),
            )
            assert result.returncode == 0
            receipt_path = os.path.join(tmpdir, "validation_receipt.json")
            with open(receipt_path) as f:
                receipt = json.load(f)
            fp = receipt["input_manifest_fingerprint"]
            assert fp != "PLACEHOLDER_SKELETON_NO_OP"
            assert len(fp) == 64

    def test_cli_no_input_dirs_still_placeholder_fingerprint(self) -> None:
        """CLI with no input dirs still writes PLACEHOLDER_SKELETON_NO_OP."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
            )
            assert result.returncode == 0
            receipt_path = os.path.join(tmpdir, "validation_receipt.json")
            with open(receipt_path) as f:
                receipt = json.load(f)
            assert receipt["input_manifest_fingerprint"] == "PLACEHOLDER_SKELETON_NO_OP"

    def test_cli_with_fixture_dirs_final_verdict_still_skeleton_only(self) -> None:
        """final_verdict remains SKELETON_ONLY even with fixture dirs."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--bars-dir",
                str(FIXTURE_DIR),
            )
            assert result.returncode == 0
            receipt_path = os.path.join(tmpdir, "validation_receipt.json")
            with open(receipt_path) as f:
                receipt = json.load(f)
            assert receipt["final_verdict"] == "SKELETON_ONLY"
            assert receipt["final_verdict"] != "EDGE_CANDIDATE"

    def test_cli_refuses_srv_qnty_path_via_bars_dir(self) -> None:
        """Using --bars-dir pointing under /srv/qnty fails."""
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--bars-dir",
            "/srv/qnty/data/bars",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_cli_refuses_srv_qnty_path_via_funding_dir(self) -> None:
        """Using --funding-dir pointing under /srv/qnty fails."""
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--funding-dir",
            "/srv/qnty/data/funding",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_cli_refuses_srv_qnty_path_via_manifest_dir(self) -> None:
        """Using --manifest-dir pointing under /srv/qnty fails."""
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--manifest-dir",
            "/srv/qnty/manifests/v1",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_cli_fingerprint_deterministic_across_invocations(self) -> None:
        """Fingerprint is deterministic across separate CLI invocations."""
        with tempfile.TemporaryDirectory() as tmpdir1:
            result1 = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir1,
                "--bars-dir",
                str(FIXTURE_DIR),
            )
            assert result1.returncode == 0

            with tempfile.TemporaryDirectory() as tmpdir2:
                result2 = _run_cli(
                    "--read-only",
                    "--output-dir",
                    tmpdir2,
                    "--bars-dir",
                    str(FIXTURE_DIR),
                )
                assert result2.returncode == 0

                with open(os.path.join(tmpdir1, "validation_receipt.json")) as f:
                    r1 = json.load(f)
                with open(os.path.join(tmpdir2, "validation_receipt.json")) as f:
                    r2 = json.load(f)
                assert r1["input_manifest_fingerprint"] == r2["input_manifest_fingerprint"]


class TestInputManifestSummaryInReceipt:
    """Tests for input_manifest_summary in receipt when fixture dirs provided."""

    def test_summary_present_when_fixture_dirs_provided(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--bars-dir",
                str(FIXTURE_DIR),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert "input_manifest_summary" in receipt
            summary = receipt["input_manifest_summary"]
            assert "file_count" in summary
            assert summary["file_count"] > 0
            assert "files" in summary
            assert "fingerprint" in summary
            assert len(summary["fingerprint"]) == 64

    def test_summary_not_present_without_fixture_dirs(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert "input_manifest_summary" not in receipt

    def test_summary_fingerprint_matches_top_level(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--bars-dir",
                str(FIXTURE_DIR),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert receipt["input_manifest_summary"]["fingerprint"] == receipt["input_manifest_fingerprint"]


class TestVolnormFixtureReconstruction:
    """PR D — CLI --volnorm-bars produces a fixture-only volnorm summary."""

    VOLNORM_BARS = FIXTURE_DIR / "sample_volnorm_bars.csv"

    def test_cli_with_volnorm_bars_emits_summary(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert "volnorm_fixture_summary" in receipt
            summary = receipt["volnorm_fixture_summary"]
            assert summary["volnorm_version"] == "fixture-0.1"
            assert summary["bar_count"] == 6
            assert "realized_volatility" in summary
            assert "inverse_vol_weight" in summary

    def test_cli_volnorm_stage_metric_present(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            stages = receipt["per_stage_metrics"]
            assert "A" in stages
            assert stages["A"]["stage_name"] == "fixture_volnorm_reconstruction"
            assert stages["A"]["status"] == "SKELETON_ONLY"

    def test_cli_volnorm_still_skeleton_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert receipt["final_verdict"] == "SKELETON_ONLY"
            assert receipt["final_verdict"] != "EDGE_CANDIDATE"

    def test_cli_volnorm_no_pnl_or_edge_keys(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            for forbidden in ("pnl", "strategy_performance", "edge_candidate", "sharpe"):
                assert forbidden not in receipt

    def test_cli_refuses_srv_qnty_volnorm_bars(self) -> None:
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--volnorm-bars",
            "/srv/qnty/data/bars/sample.csv",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_cli_volnorm_summary_deterministic(self) -> None:
        summaries = []
        for _ in range(2):
            with tempfile.TemporaryDirectory() as tmpdir:
                result = _run_cli(
                    "--read-only",
                    "--output-dir",
                    tmpdir,
                    "--volnorm-bars",
                    str(self.VOLNORM_BARS),
                )
                assert result.returncode == 0
                with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                    summaries.append(json.load(f)["volnorm_fixture_summary"])
        assert summaries[0] == summaries[1]

    def test_cli_without_volnorm_bars_omits_summary(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli("--read-only", "--output-dir", tmpdir)
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert "volnorm_fixture_summary" not in receipt


class TestWalkforwardFixtureReplay:
    """PR E — CLI --walkforward-bars produces a fixture-only walk-forward summary."""

    WALKFORWARD_BARS = FIXTURE_DIR / "sample_walkforward_bars.csv"

    def test_cli_with_walkforward_bars_emits_summary(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert "walkforward_fixture_summary" in receipt
            summary = receipt["walkforward_fixture_summary"]
            assert summary["walkforward_version"] == "fixture-0.1"
            assert summary["split_count"] >= 2
            assert "fixture_counterfactual_return_total" in summary

    def test_cli_walkforward_stage_b_metric_present(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            stages = receipt["per_stage_metrics"]
            assert "B" in stages
            assert stages["B"]["stage_name"] == "fixture_walkforward_replay"
            assert stages["B"]["status"] == "SKELETON_ONLY"

    def test_cli_walkforward_still_skeleton_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert receipt["final_verdict"] == "SKELETON_ONLY"
            assert receipt["final_verdict"] != "EDGE_CANDIDATE"

    def test_cli_walkforward_no_pnl_or_edge_keys(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            for forbidden in ("pnl", "strategy_performance", "edge_candidate", "sharpe", "edge"):
                assert forbidden not in receipt

    def test_cli_refuses_srv_qnty_walkforward_bars(self) -> None:
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--walkforward-bars",
            "/srv/qnty/data/bars/sample.csv",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_cli_walkforward_summary_deterministic(self) -> None:
        summaries = []
        for _ in range(2):
            with tempfile.TemporaryDirectory() as tmpdir:
                result = _run_cli(
                    "--read-only",
                    "--output-dir",
                    tmpdir,
                    "--walkforward-bars",
                    str(self.WALKFORWARD_BARS),
                )
                assert result.returncode == 0
                with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                    summaries.append(json.load(f)["walkforward_fixture_summary"])
        assert summaries[0] == summaries[1]

    def test_cli_without_walkforward_bars_omits_summary(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli("--read-only", "--output-dir", tmpdir)
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert "walkforward_fixture_summary" not in receipt
            assert "B" not in receipt["per_stage_metrics"]


class TestInputManifestFingerprintMatchesDirect:
    """Verify CLI's fingerprint matches a direct call to discover_input_files."""

    def test_cli_fingerprint_matches_direct_computation(self) -> None:
        """Fingerprint from CLI run matches directly calling discover_input_files + compute."""
        discovered = discover_input_files([FIXTURE_DIR])
        expected_fp = compute_input_manifest_fingerprint(discovered)

        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--bars-dir",
                str(FIXTURE_DIR),
                "--funding-dir",
                str(FIXTURE_DIR),
                "--manifest-dir",
                str(FIXTURE_DIR),
            )
            assert result.returncode == 0
            with open(os.path.join(tmpdir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert receipt["input_manifest_fingerprint"] == expected_fp


# ---------------------------------------------------------------------------
# TestFullFixtureReceiptFlag  (PR F)
# ---------------------------------------------------------------------------


class TestFullFixtureReceiptFlag:
    """Tests for ``--full-fixture-receipt`` flag (PR F)."""

    VOLNORM_BARS = FIXTURE_DIR / "sample_volnorm_bars.csv"
    WALKFORWARD_BARS = FIXTURE_DIR / "sample_walkforward_bars.csv"

    def test_full_fixture_receipt_writes_full_receipt(self) -> None:
        """Full receipt has all 10 top-level keys and guardrail booleans."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
                "--bars-dir",
                str(FIXTURE_DIR),
                "--full-fixture-receipt",
            )
            assert result.returncode == 0
            output_path = os.path.join(tmpdir, "validation_receipt.json")
            assert os.path.exists(output_path)
            with open(output_path) as f:
                receipt = json.load(f)
            # All 10 top-level keys present
            expected_keys = {
                "validation_receipt",
                "input_manifest_fingerprint",
                "input_manifest_summary",
                "cost_model_assumptions",
                "per_stage_metrics",
                "volnorm_fixture_summary",
                "walkforward_fixture_summary",
                "guardrail_status",
                "final_verdict",
                "final_verdict_rationale",
            }
            assert set(receipt.keys()) == expected_keys
            # Guardrail booleans
            gs = receipt["guardrail_status"]
            assert gs["edge_unproven"] is True
            assert gs["block_live_integration"] is True
            assert gs["clean_net_of_carry_is_not_edge"] is True
            assert gs["long_only_1x_only"] is True
            assert gs["fixture_only"] is True
            # Verdict
            assert receipt["final_verdict"] == "SKELETON_ONLY"
            assert receipt["final_verdict"] != "EDGE_CANDIDATE"
            # No forbidden keys
            for forbidden in ("pnl", "sharpe", "edge", "strategy_performance"):
                assert forbidden not in receipt

    def test_full_fixture_receipt_refuses_missing_volnorm_bars(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
                "--full-fixture-receipt",
            )
            assert result.returncode == 1
            assert "--volnorm-bars" in result.stderr

    def test_full_fixture_receipt_refuses_missing_walkforward_bars(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
                "--full-fixture-receipt",
            )
            assert result.returncode == 1
            assert "--walkforward-bars" in result.stderr

    def test_full_fixture_receipt_refuses_without_input_dirs(self) -> None:
        """--full-fixture-receipt requires at least one of --bars-dir, --funding-dir, --manifest-dir."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
                "--full-fixture-receipt",
            )
            assert result.returncode == 1
            assert "at least one of --bars-dir, --funding-dir, --manifest-dir" in result.stderr

    def test_full_fixture_receipt_succeeds_with_input_dirs(self) -> None:
        """--full-fixture-receipt succeeds with --bars-dir pointing to golden fixtures."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
                "--bars-dir",
                str(FIXTURE_DIR),
                "--full-fixture-receipt",
            )
            assert result.returncode == 0
            assert "Full fixture receipt written to" in result.stdout

    def test_full_fixture_receipt_output_path(self) -> None:
        """Full receipt writes to <--output-dir>/validation_receipt.json, not /tmp/."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
                "--bars-dir",
                str(FIXTURE_DIR),
                "--full-fixture-receipt",
            )
            assert result.returncode == 0
            output_path = os.path.join(tmpdir, "validation_receipt.json")
            assert os.path.exists(output_path)
            # Should NOT exist at the old hardcoded path
            assert not os.path.exists("/tmp/validation_receipt.json")

    def test_full_fixture_receipt_has_non_null_input_manifest_summary(self) -> None:
        """Full receipt has non-null input_manifest_summary and non-placeholder fingerprint."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
                "--bars-dir",
                str(FIXTURE_DIR),
                "--full-fixture-receipt",
            )
            assert result.returncode == 0
            output_path = os.path.join(tmpdir, "validation_receipt.json")
            with open(output_path) as f:
                receipt = json.load(f)
            assert receipt["input_manifest_summary"] is not None
            assert receipt["input_manifest_fingerprint"] != "PLACEHOLDER_SKELETON_NO_OP"

    def test_full_fixture_receipt_single_output(self) -> None:
        """Only one validation_receipt.json — at the expected output path, not /tmp/."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = _run_cli(
                "--read-only",
                "--output-dir",
                tmpdir,
                "--volnorm-bars",
                str(self.VOLNORM_BARS),
                "--walkforward-bars",
                str(self.WALKFORWARD_BARS),
                "--bars-dir",
                str(FIXTURE_DIR),
                "--full-fixture-receipt",
            )
            assert result.returncode == 0
            output_path = os.path.join(tmpdir, "validation_receipt.json")
            assert os.path.exists(output_path)
            # No receipt leaked to the old hardcoded path
            assert not os.path.exists("/tmp/validation_receipt.json")

    def test_full_fixture_receipt_refuses_prod_path(self) -> None:
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--volnorm-bars",
            "/srv/qnty/data/bars/sample.csv",
            "--walkforward-bars",
            str(self.WALKFORWARD_BARS),
            "--full-fixture-receipt",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_full_fixture_receipt_refuses_prod_path_on_input_dirs(self) -> None:
        """--bars-dir pointing under /srv/qnty with --full-fixture-receipt exits 3."""
        result = _run_cli(
            "--read-only",
            "--output-dir",
            "/tmp/safe_output",
            "--volnorm-bars",
            str(self.VOLNORM_BARS),
            "--walkforward-bars",
            str(self.WALKFORWARD_BARS),
            "--bars-dir",
            "/srv/qnty/data/bars",
            "--full-fixture-receipt",
        )
        assert result.returncode == 3
        assert "Refusing" in result.stdout

    def test_full_fixture_receipt_deterministic(self) -> None:
        """Full receipt is deterministic (excluding timestamp) across invocations."""
        receipts = []
        for _ in range(2):
            with tempfile.TemporaryDirectory() as tmpdir:
                result = _run_cli(
                    "--read-only",
                    "--output-dir",
                    tmpdir,
                    "--volnorm-bars",
                    str(self.VOLNORM_BARS),
                    "--walkforward-bars",
                    str(self.WALKFORWARD_BARS),
                    "--bars-dir",
                    str(FIXTURE_DIR),
                    "--full-fixture-receipt",
                )
                assert result.returncode == 0
                output_path = os.path.join(tmpdir, "validation_receipt.json")
                assert os.path.exists(output_path)
                with open(output_path) as f:
                    receipts.append(json.load(f))
        # Compare excluding timestamp
        for r in receipts:
            r["validation_receipt"].pop("timestamp_utc")
        assert receipts[0] == receipts[1]

    def test_full_fixture_receipt_cost_model_fields(self) -> None:
        """Full fixture receipt cost_model_assumptions includes all PR C fields."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "cost_fields_test"
            output_dir.mkdir(parents=True, exist_ok=True)
            result = _run_cli(
                "--read-only",
                "--output-dir", str(output_dir),
                "--bars-dir", str(FIXTURE_DIR),
                "--volnorm-bars", str(FIXTURE_DIR / "sample_volnorm_bars.csv"),
                "--walkforward-bars", str(FIXTURE_DIR / "sample_walkforward_bars.csv"),
                "--full-fixture-receipt",
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"
            receipt_path = output_dir / "validation_receipt.json"
            assert receipt_path.exists()
            with open(receipt_path) as f:
                receipt = json.loads(f.read())
            cost = receipt.get("cost_model_assumptions", {})
            assert cost.get("spread_bps_per_side") == 1.0, f"Expected spread_bps_per_side=1.0, got {cost.get('spread_bps_per_side')}"
            assert cost.get("funding_cost_placeholder") == 0.0, f"Expected funding_cost_placeholder=0.0, got {cost.get('funding_cost_placeholder')}"
            assert cost.get("cost_model_version") is not None
            assert cost.get("slippage_bps_per_side") is not None
            assert cost.get("commission_bps_per_side") is not None
            assert cost.get("heat_cap") is not None
            assert cost.get("vol_lookback_bars") is not None
            assert cost.get("vol_floor") is not None
            # Verify no regression
            assert receipt["final_verdict"] == "SKELETON_ONLY"
            assert "EDGE_CANDIDATE" not in str(receipt)
            assert "pnl" not in receipt
            assert "sharpe" not in receipt
            assert "edge" not in receipt
            assert "strategy_performance" not in receipt
            # Cleanup
            shutil.rmtree(output_dir)

    def test_full_fixture_receipt_cleanup(self) -> None:
        """Clean up any leftover /tmp/validation_receipt.json from other tests."""
        full_path = "/tmp/validation_receipt.json"
        if os.path.exists(full_path):
            os.unlink(full_path)
        assert not os.path.exists(full_path)


class TestDataQualityPreflight:
    """CLI integration tests for --data-quality-preflight flag."""

    def test_emits_summary_when_flag_provided(self):
        """--data-quality-preflight with --bars-dir should emit data_quality_preflight_summary."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                 "--read-only", "--output-dir", tmpdir, "--bars-dir", str(FIXTURE_DIR),
                 "--data-quality-preflight"],
                capture_output=True, text=True
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"

            receipt_path = pathlib.Path(tmpdir) / "validation_receipt.json"
            assert receipt_path.exists(), "Receipt not written"

            receipt = json.loads(receipt_path.read_text())
            assert "data_quality_preflight_summary" in receipt, (
                f"Missing data_quality_preflight_summary in receipt keys: {list(receipt.keys())}"
            )
            summary = receipt["data_quality_preflight_summary"]
            assert "data_quality_version" in summary
            assert "readiness_flags" in summary
            assert summary["readiness_flags"]["data_quality_preflight_only"] is True

    def test_refuses_without_input_dirs(self):
        """--data-quality-preflight without --bars-dir/--funding-dir/--manifest-dir should fail."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                 "--read-only", "--output-dir", tmpdir, "--data-quality-preflight"],
                capture_output=True, text=True
            )
            assert result.returncode == 1, (
                f"Expected exit code 1, got {result.returncode}: {result.stderr}"
            )

    def test_final_verdict_remains_skeleton_only(self):
        """Even with --data-quality-preflight, final_verdict must be SKELETON_ONLY."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                 "--read-only", "--output-dir", tmpdir, "--bars-dir", str(FIXTURE_DIR),
                 "--data-quality-preflight"],
                capture_output=True, text=True
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"

            receipt = json.loads((pathlib.Path(tmpdir) / "validation_receipt.json").read_text())
            assert receipt["final_verdict"] == "SKELETON_ONLY"

    def test_no_forbidden_top_level_keys(self):
        """Receipt must not contain pnl, sharpe, edge, or strategy_performance at top level."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                 "--read-only", "--output-dir", tmpdir, "--bars-dir", str(FIXTURE_DIR),
                 "--data-quality-preflight"],
                capture_output=True, text=True
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"

            receipt = json.loads((pathlib.Path(tmpdir) / "validation_receipt.json").read_text())
            forbidden = {"pnl", "sharpe", "edge", "strategy_performance"}
            found = [k for k in forbidden if k in receipt]
            assert not found, f"Found forbidden top-level keys: {found}"

    def test_stage_c_present(self):
        """Stage C (data_quality_preflight) should be in per_stage_metrics."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                 "--read-only", "--output-dir", tmpdir, "--bars-dir", str(FIXTURE_DIR),
                 "--data-quality-preflight"],
                capture_output=True, text=True
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"

            receipt = json.loads((pathlib.Path(tmpdir) / "validation_receipt.json").read_text())
            per_stage = receipt["per_stage_metrics"]
            assert "C" in per_stage, f"Stage C not found in stages: {list(per_stage.keys())}"
            assert per_stage["C"]["stage_name"] == "data_quality_preflight"

    def test_works_with_funding_dir(self):
        """--data-quality-preflight should work with --funding-dir."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                 "--read-only", "--output-dir", tmpdir, "--funding-dir", str(FIXTURE_DIR),
                 "--data-quality-preflight"],
                capture_output=True, text=True
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"

            receipt = json.loads((pathlib.Path(tmpdir) / "validation_receipt.json").read_text())
            assert "data_quality_preflight_summary" in receipt

    def test_works_with_manifest_dir(self):
        """--data-quality-preflight should work with --manifest-dir."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                 "--read-only", "--output-dir", tmpdir, "--manifest-dir", str(FIXTURE_DIR),
                 "--data-quality-preflight"],
                capture_output=True, text=True
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"

            receipt = json.loads((pathlib.Path(tmpdir) / "validation_receipt.json").read_text())
            assert "data_quality_preflight_summary" in receipt

    def test_deterministic_output(self):
        """Running twice with same inputs should produce identical receipt (except timestamp)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            def _run():
                result = subprocess.run(
                    [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                     "--read-only", "--output-dir", tmpdir, "--bars-dir", str(FIXTURE_DIR),
                     "--data-quality-preflight"],
                    capture_output=True, text=True
                )
                assert result.returncode == 0, f"CLI failed: {result.stderr}"
                return json.loads((pathlib.Path(tmpdir) / "validation_receipt.json").read_text())

            receipt1 = _run()
            receipt2 = _run()

            # Compare everything except timestamp-dependent fields
            for key in receipt1:
                if key in ("validation_receipt",):
                    continue  # skip metadata which has timestamp
                assert receipt1[key] == receipt2[key], f"Mismatch in key: {key}"

    def test_full_fixture_receipt_with_data_quality(self):
        """--full-fixture-receipt with --data-quality-preflight should include summary."""
        with tempfile.TemporaryDirectory() as tmpdir:
            bars_csv = str(FIXTURE_DIR / "sample_volnorm_bars.csv")
            wf_bars_csv = str(FIXTURE_DIR / "sample_walkforward_bars.csv")
            result = subprocess.run(
                [sys.executable, "-m", "quantbot.experiment.offline_edge_validation_cli",
                 "--read-only", "--output-dir", tmpdir,
                 "--bars-dir", str(FIXTURE_DIR),
                 "--data-quality-preflight",
                 "--volnorm-bars", bars_csv,
                 "--walkforward-bars", wf_bars_csv,
                 "--full-fixture-receipt"],
                capture_output=True, text=True
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"

            receipt = json.loads((pathlib.Path(tmpdir) / "validation_receipt.json").read_text())
            assert "data_quality_preflight_summary" in receipt, (
                f"Missing data_quality_preflight_summary in full receipt keys: {list(receipt.keys())}"
            )
            # Also verify existing required keys are still present
            for key in ["validation_receipt", "input_manifest_fingerprint", "input_manifest_summary",
                        "cost_model_assumptions", "per_stage_metrics", "volnorm_fixture_summary",
                        "walkforward_fixture_summary", "guardrail_status", "final_verdict",
                        "final_verdict_rationale"]:
                assert key in receipt, f"Missing required key: {key}"

            # Verify no forbidden keys
            forbidden = {"pnl", "sharpe", "edge", "strategy_performance"}
            found = [k for k in forbidden if k in receipt]
            assert not found, f"Found forbidden top-level keys: {found}"


class TestDataQualitySchemaProfiles:
    """PR I — CLI --bars-dir / --funding-dir / --manifest-dir use distinct
    schema-aware data-quality profiles instead of one generic required-column
    set, so real Binance funding CSVs are not wrongly judged against the
    bars/OHLCV column requirements."""

    def _bars_only_dir(self, tmpdir: str) -> str:
        bars_dir = os.path.join(tmpdir, "bars_only")
        os.makedirs(bars_dir)
        shutil.copy(
            FIXTURE_DIR / "data_quality_clean.csv",
            os.path.join(bars_dir, "data_quality_clean.csv"),
        )
        return bars_dir

    def _funding_only_dir(self, tmpdir: str) -> str:
        funding_dir = os.path.join(tmpdir, "funding_only")
        os.makedirs(funding_dir)
        shutil.copy(
            FIXTURE_DIR / "data_quality_funding_clean.csv",
            os.path.join(funding_dir, "data_quality_funding_clean.csv"),
        )
        return funding_dir

    def test_cli_uses_bars_and_funding_profiles(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bars_dir = self._bars_only_dir(tmpdir)
            funding_dir = self._funding_only_dir(tmpdir)
            output_dir = os.path.join(tmpdir, "out")
            result = _run_cli(
                "--read-only",
                "--output-dir", output_dir,
                "--bars-dir", bars_dir,
                "--funding-dir", funding_dir,
                "--data-quality-preflight",
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"
            with open(os.path.join(output_dir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            summary = receipt["data_quality_preflight_summary"]
            assert summary["roles"]["bars"]["profile"] == "bars"
            assert summary["roles"]["funding"]["profile"] == "funding"
            # Funding coverage must not fail for missing close/volume.
            assert summary["missing_required_columns_by_role"]["funding"] == []
            assert summary["readiness_flags"]["by_role"]["funding"][
                "has_timestamp_column"
            ] is True

    def test_cli_funding_dir_null_mark_price_does_not_fail_readiness(self) -> None:
        """Optional markPrice nulls must not fail funding readiness in the
        CLI receipt — required-column-only null semantics (repair)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            funding_dir = os.path.join(tmpdir, "funding_null_mark_price")
            os.makedirs(funding_dir)
            shutil.copy(
                FIXTURE_DIR / "data_quality_funding_null_mark_price.csv",
                os.path.join(funding_dir, "data_quality_funding_null_mark_price.csv"),
            )
            output_dir = os.path.join(tmpdir, "out")
            result = _run_cli(
                "--read-only",
                "--output-dir", output_dir,
                "--funding-dir", funding_dir,
                "--data-quality-preflight",
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"
            with open(os.path.join(output_dir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            summary = receipt["data_quality_preflight_summary"]
            assert summary["has_null_values"] is False
            assert summary["readiness_flags"]["no_null_required_values"] is True
            assert summary["readiness_flags"]["by_role"]["funding"][
                "no_null_required_values"
            ] is True
            # Final verdict and forbidden-key guardrails still hold.
            assert receipt["final_verdict"] == "SKELETON_ONLY"
            assert receipt["final_verdict"] != "EDGE_CANDIDATE"
            for forbidden in ("pnl", "sharpe", "edge", "strategy_performance"):
                assert forbidden not in receipt
            assert "EDGE_CANDIDATE" not in json.dumps(receipt)

    def test_cli_funding_dir_missing_funding_time_flagged_not_bars(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            funding_dir = os.path.join(tmpdir, "funding_bad")
            os.makedirs(funding_dir)
            with open(os.path.join(funding_dir, "no_funding_time.csv"), "w") as f:
                f.write("symbol,fundingRate,markPrice\nBTCUSDT,0.0001,45000.0\n")
            output_dir = os.path.join(tmpdir, "out")
            result = _run_cli(
                "--read-only",
                "--output-dir", output_dir,
                "--funding-dir", funding_dir,
                "--data-quality-preflight",
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"
            with open(os.path.join(output_dir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            summary = receipt["data_quality_preflight_summary"]
            assert "fundingTime" in summary["missing_required_columns_by_role"]["funding"]
            assert summary["readiness_flags"]["by_role"]["funding"][
                "has_timestamp_column"
            ] is False

    def test_cli_receipt_with_funding_schema_has_no_forbidden_keys(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bars_dir = self._bars_only_dir(tmpdir)
            funding_dir = self._funding_only_dir(tmpdir)
            output_dir = os.path.join(tmpdir, "out")
            result = _run_cli(
                "--read-only",
                "--output-dir", output_dir,
                "--bars-dir", bars_dir,
                "--funding-dir", funding_dir,
                "--data-quality-preflight",
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"
            with open(os.path.join(output_dir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            for forbidden in ("pnl", "sharpe", "edge", "strategy_performance"):
                assert forbidden not in receipt
            assert "EDGE_CANDIDATE" not in json.dumps(receipt)
            assert receipt["final_verdict"] == "SKELETON_ONLY"

    def test_cli_manifest_dir_uses_manifest_profile(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manifest_dir = os.path.join(tmpdir, "manifest_only")
            os.makedirs(manifest_dir)
            with open(os.path.join(manifest_dir, "sample_manifest.json"), "w") as f:
                f.write('{"bars": "a.csv"}')
            output_dir = os.path.join(tmpdir, "out")
            result = _run_cli(
                "--read-only",
                "--output-dir", output_dir,
                "--manifest-dir", manifest_dir,
                "--data-quality-preflight",
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"
            with open(os.path.join(output_dir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            summary = receipt["data_quality_preflight_summary"]
            assert summary["roles"]["manifest"]["profile"] == "manifest"
            # Manifest profile requires no OHLCV columns at all.
            assert summary["missing_required_columns_by_role"]["manifest"] == []
            manifest_entry = summary["roles"]["manifest"]["files"][0]
            assert manifest_entry["kind"] == "manifest_json"
            assert manifest_entry["is_valid_json"] is True

    def test_cli_final_verdict_still_skeleton_only_with_schema_profiles(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            bars_dir = self._bars_only_dir(tmpdir)
            funding_dir = self._funding_only_dir(tmpdir)
            output_dir = os.path.join(tmpdir, "out")
            result = _run_cli(
                "--read-only",
                "--output-dir", output_dir,
                "--bars-dir", bars_dir,
                "--funding-dir", funding_dir,
                "--data-quality-preflight",
            )
            assert result.returncode == 0, f"CLI failed: {result.stderr}"
            with open(os.path.join(output_dir, "validation_receipt.json")) as f:
                receipt = json.load(f)
            assert receipt["final_verdict"] == "SKELETON_ONLY"
            assert receipt["final_verdict"] != "EDGE_CANDIDATE"