"""Tests for quantbot/experiment/offline_edge_schema.py

PR A — safe skeleton schema tests.
"""

import pytest
from quantbot.experiment.offline_edge_schema import (
    ReceiptMetadata,
    CostModelAssumptions,
    FIXTURE_VOLNORM_STAGE_ID,
    FIXTURE_VOLNORM_STAGE_NAME,
    FIXTURE_WALKFORWARD_STAGE_ID,
    FIXTURE_WALKFORWARD_STAGE_NAME,
    PLACEHOLDER_SKELETON_NO_OP,
    StageMetrics,
    ValidationReceipt,
    SKELETON_ONLY,
    INCONCLUSIVE,
    EDGE_CANDIDATE,
    NO_EDGE,
    NEEDS_MORE_DATA,
    BLOCKED_BY_DATA_QUALITY,
    validate_skeleton_verdict,
)


class TestFixtureStageConstants:
    def test_volnorm_stage_identity(self):
        assert FIXTURE_VOLNORM_STAGE_ID == "A"
        assert FIXTURE_VOLNORM_STAGE_NAME == "fixture_volnorm_reconstruction"

    def test_walkforward_stage_identity(self):
        # PR E — fixture-only walk-forward replay stage.
        assert FIXTURE_WALKFORWARD_STAGE_ID == "B"
        assert FIXTURE_WALKFORWARD_STAGE_NAME == "fixture_walkforward_replay"


class TestSchemaConstants:
    def test_allowed_verdicts(self):
        assert SKELETON_ONLY == "SKELETON_ONLY"
        assert INCONCLUSIVE == "INCONCLUSIVE"

    def test_forbidden_future_verdicts_named(self):
        # These constants must exist for refusal tests even though not allowed
        assert EDGE_CANDIDATE == "EDGE_CANDIDATE"
        assert NO_EDGE == "NO_EDGE"
        assert NEEDS_MORE_DATA == "NEEDS_MORE_DATA"
        assert BLOCKED_BY_DATA_QUALITY == "BLOCKED_BY_DATA_QUALITY"

    def test_placeholder_skeleton_no_op_constant(self):
        assert PLACEHOLDER_SKELETON_NO_OP == "PLACEHOLDER_SKELETON_NO_OP"


class TestCostModelDefaults:
    def test_defaults_match_spec(self):
        assumptions = CostModelAssumptions(
            slippage_bps_per_side=5.0,
            commission_bps_per_side=5.0,
            heat_cap=1.0,
            vol_lookback_bars=90,
            vol_floor=1e-6,
        )
        assert assumptions["slippage_bps_per_side"] == 5.0
        assert assumptions["commission_bps_per_side"] == 5.0
        assert assumptions["heat_cap"] == 1.0
        assert assumptions["vol_lookback_bars"] == 90
        assert assumptions["vol_floor"] == 1e-6


class TestCostModelPRCFields:
    def test_prc_fields_accepted(self):
        # PR C fixture-only cost-model fields are backwards-compatible additions.
        assumptions = CostModelAssumptions(
            slippage_bps_per_side=5.0,
            commission_bps_per_side=5.0,
            heat_cap=1.0,
            vol_lookback_bars=90,
            vol_floor=1e-6,
            cost_model_version="1.0",
            spread_bps_per_side=1.0,
            funding_cost_placeholder=0.0,
        )
        assert assumptions["cost_model_version"] == "1.0"
        assert assumptions["spread_bps_per_side"] == 1.0
        assert assumptions["funding_cost_placeholder"] == 0.0

    def test_legacy_assumptions_still_valid_without_prc_fields(self):
        # Existing PR-A/B receipts omit the new keys; construction must not fail.
        assumptions = CostModelAssumptions(
            slippage_bps_per_side=5.0,
            commission_bps_per_side=5.0,
            heat_cap=1.0,
            vol_lookback_bars=90,
            vol_floor=1e-6,
        )
        assert "cost_model_version" not in assumptions


class TestValidateSkeletonVerdict:
    def test_accepts_skeleton_only(self):
        assert validate_skeleton_verdict(SKELETON_ONLY) == SKELETON_ONLY

    def test_accepts_inconclusive(self):
        assert validate_skeleton_verdict(INCONCLUSIVE) == INCONCLUSIVE

    def test_rejects_edge_candidate(self):
        with pytest.raises(ValueError, match="EDGE_CANDIDATE"):
            validate_skeleton_verdict(EDGE_CANDIDATE)

    def test_rejects_no_edge(self):
        with pytest.raises(ValueError):
            validate_skeleton_verdict(NO_EDGE)

    def test_rejects_random_verdict(self):
        with pytest.raises(ValueError):
            validate_skeleton_verdict("SOME_RANDOM_VERDICT")


class TestReceiptMetadataStructure:
    def test_receipt_metadata_fields(self):
        meta = ReceiptMetadata(
            tool_name="offline_edge_validator",
            tool_version="0.1.0",
            timestamp_utc="2026-07-09T00:00:00Z",
            pipeline_description="skeleton",
        )
        assert meta["tool_name"] == "offline_edge_validator"
        assert meta["tool_version"] == "0.1.0"
        assert meta["timestamp_utc"] == "2026-07-09T00:00:00Z"
        assert meta["pipeline_description"] == "skeleton"


class TestStageMetricsStructure:
    def test_stage_metrics_fields(self):
        stage = StageMetrics(
            stage_id="A",
            stage_name="data_quality",
            status="SKELETON_ONLY",
            summary="placeholder",
        )
        assert stage["stage_id"] == "A"
        assert stage["stage_name"] == "data_quality"
        assert stage["status"] == "SKELETON_ONLY"
        assert stage["summary"] == "placeholder"


class TestValidationReceiptStructure:
    def test_receipt_all_required_keys(self):
        receipt = ValidationReceipt(
            validation_receipt=ReceiptMetadata(
                tool_name="offline_edge_validator",
                tool_version="0.1.0",
                timestamp_utc="2026-07-09T00:00:00Z",
                pipeline_description="skeleton",
            ),
            input_manifest_fingerprint="abc123",
            cost_model_assumptions=CostModelAssumptions(
                slippage_bps_per_side=5.0,
                commission_bps_per_side=5.0,
                heat_cap=1.0,
                vol_lookback_bars=90,
                vol_floor=1e-6,
            ),
            per_stage_metrics={},
            final_verdict=SKELETON_ONLY,
        )
        assert set(receipt.keys()) == {
            "validation_receipt",
            "input_manifest_fingerprint",
            "cost_model_assumptions",
            "per_stage_metrics",
            "final_verdict",
        }
        assert receipt["final_verdict"] == SKELETON_ONLY

    def test_receipt_with_placeholder_fingerprint(self):
        receipt = ValidationReceipt(
            validation_receipt=ReceiptMetadata(
                tool_name="offline_edge_validator",
                tool_version="0.1.0",
                timestamp_utc="2026-07-09T00:00:00Z",
                pipeline_description="skeleton",
            ),
            input_manifest_fingerprint=PLACEHOLDER_SKELETON_NO_OP,
            cost_model_assumptions=CostModelAssumptions(
                slippage_bps_per_side=5.0,
                commission_bps_per_side=5.0,
                heat_cap=1.0,
                vol_lookback_bars=90,
                vol_floor=1e-6,
            ),
            per_stage_metrics={},
            final_verdict=SKELETON_ONLY,
        )
        assert receipt["input_manifest_fingerprint"] == PLACEHOLDER_SKELETON_NO_OP